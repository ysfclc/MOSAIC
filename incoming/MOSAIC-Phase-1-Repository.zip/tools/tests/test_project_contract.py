import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

class ProjectContractTests(unittest.TestCase):
    def test_architecture_declares_single_media_core(self):
        text = (ROOT / "docs/ARCHITECTURE.md").read_text(encoding="utf-8")
        self.assertIn("one app-wide `PlaybackService`", text)
        self.assertIn("MediaSourceAdapter", text)

    def test_phase_one_does_not_claim_provider_bypass(self):
        text = (ROOT / "docs/DECISIONS.md").read_text(encoding="utf-8")
        self.assertIn("no ad removal", text)
        self.assertIn("paywall bypass", text)

    def test_workflow_is_present(self):
        self.assertTrue((ROOT / ".github/workflows/build-apk.yml").is_file())

    def test_phase_one_is_offline_by_default(self):
        manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
        self.assertNotIn("android.permission.INTERNET", manifest)

    def test_playback_service_owns_audio_focus_and_wake_mode(self):
        source = (ROOT / "core/media/src/main/java/com/ysfclc/mosaic/core/media/PlaybackService.kt").read_text(encoding="utf-8")
        self.assertIn("setAudioAttributes(AudioAttributes.DEFAULT", source)
        self.assertIn("setWakeMode(C.WAKE_MODE_LOCAL)", source)

    def test_video_is_not_advertised_before_video_surface_exists(self):
        readme = (ROOT / "README.md").read_text(encoding="utf-8")
        self.assertIn("Phase 1 deliberately exposes audio playback only", readme)

if __name__ == "__main__":
    unittest.main()
