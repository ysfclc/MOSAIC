#!/usr/bin/env python3
"""Fast structural verifier for the MOSAIC source snapshot."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/ysfclc/mosaic/MainActivity.kt",
    "app/src/main/java/com/ysfclc/mosaic/ui/MosaicApp.kt",
    "core/media/build.gradle.kts",
    "core/library/build.gradle.kts",
    "core/design/build.gradle.kts",
    "docs/ARCHITECTURE.md",
    "docs/PHASES.md",
    "docs/TASKS.md",
    "PROJECT_STATE.md",
]

def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)

missing = [p for p in REQUIRED if not (ROOT / p).is_file()]
if missing:
    fail("required project files missing: " + ", ".join(missing))

manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
service = (ROOT / "core/media/src/main/java/com/ysfclc/mosaic/core/media/PlaybackService.kt").read_text(encoding="utf-8")
contract = (ROOT / "core/media/src/main/java/com/ysfclc/mosaic/core/media/MediaSource.kt").read_text(encoding="utf-8")
workflow = ROOT / ".github/workflows/build-apk.yml"
checks = {
    "media playback foreground permission": "FOREGROUND_SERVICE_MEDIA_PLAYBACK" in manifest,
    "single MediaSessionService declaration": manifest.count("androidx.media3.session.MediaSessionService") == 1,
    "mediaPlayback foreground service type": 'android:foregroundServiceType="mediaPlayback"' in manifest,
    "screen-off wake lock permission": "android.permission.WAKE_LOCK" in manifest,
    "local playback wake mode": "setWakeMode(C.WAKE_MODE_LOCAL)" in service,
    "automatic audio focus": "setAudioAttributes(AudioAttributes.DEFAULT" in service,
    "service is a MediaSessionService": "MediaSessionService" in service,
    "source adapter contract": "interface MediaSourceAdapter" in contract,
    "explicit source capabilities": "class SourceCapabilities" in contract,
    "current architecture notes": (ROOT / "docs/ARCHITECTURE.md").is_file(),
    "workflow template included": workflow.is_file(),
    "Phase 1 has no unnecessary network permission": "android.permission.INTERNET" not in manifest,
    "Phase 1 picker is audio-only until video UI exists": 'documentLauncher.launch(arrayOf("audio/*"))' in (ROOT / "app/src/main/java/com/ysfclc/mosaic/ui/MosaicApp.kt").read_text(encoding="utf-8"),
}
failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
if failed:
    fail("one or more architecture invariants failed")

# Guard the source tree against accidental claims that future integrations are already implemented.
source_text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in ROOT.rglob("*.kt"))
if re.search(r"TODO\(phase1\)", source_text, flags=re.IGNORECASE):
    fail("found an unresolved Phase 1 placeholder marker")
print("MOSAIC source structure verified. This is not a substitute for Gradle or device testing.")
