# Product specification — MOSAIC

## Product statement

A native, local-first personal media environment that lets a person collect, organize and play content from multiple legitimate sources through one consistent interface, then optionally turn that content into searchable personal knowledge.

## Primary job to be done

“When I find something worth listening to or watching, I want to keep it accessible, continue it in the context I prefer, and organize it without being forced into a particular provider's app, account or subscription for capabilities I can own locally.”

## User promise

- Local media remains playable without an account or cloud.
- The app itself does not insert advertisements.
- Background playback is native for sources that permit it.
- The library is unified without destroying original folders.
- Sources advertise capabilities honestly.
- The user can export their metadata and choose backup destinations.

## User groups

1. **Personal media owner:** large local collection, wants indexing and reliable playback.
2. **Cross-source listener:** uses music, podcasts, internet radio and educational media.
3. **Browser-first collector:** saves articles, pages, videos and audio links for later.
4. **Knowledge-oriented listener:** wants transcripts, chapters, translation and summaries.

Phase 1 specifically serves the personal media owner and validates the playback foundation.

## Product areas

- Home: recent/continue state, library entry points and source health.
- Library: unified items, filters, collections, search and provenance.
- Player: one queue, timeline, transport, speed, timer, metadata, playback route.
- Browser: tabs, bookmarks, capture and permitted media handoff (later).
- Inbox: share-target capture and processing queue (later).
- Intelligence: transcript, translation, summary and semantic search (later; local-first).
- Settings: permissions, storage, source controls, backup, privacy and diagnostics.

## Phase 1 acceptance

See `docs/TASKS.md` and `docs/TESTING.md`. Phase 1 is accepted only after CI build/lint/unit tests and real Redmi screen-off playback tests pass. Compiling an APK does not itself prove device behavior.
