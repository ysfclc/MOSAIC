# MOSAIC import and engineering notes

This folder is durable project history. Do not delete prior import notes when integrating a newer source ZIP.

- `architecture/PHASE-1-BASELINE.md` records the first architecture lock.
- `imports/<upload-commit-sha>.md` is created by GitHub Actions after a successful ZIP integration.
- The upload source snapshot itself remains in Git history at `incoming/mosaic.zip`.
