# MOSAIC project state — session handoff

**Project:** MOSAIC / Personal Media OS  
**Repository target:** `ysfclc/mosaic` (remote creation is a one-time manual step)  
**Branch:** `main`  
**Current phase:** 1 — Native foundation and local playback  
**Architecture status:** LOCKED baseline; changes require an ADR in `docs/DECISIONS.md`  
**Last source snapshot:** 2026-10-30 · Phase 1 bootstrap

## Product contract

One native Android experience over multiple legitimate media sources. Local-first, provider-independent, no mandatory account, no mandatory subscription for core local playback, and no ads inserted by MOSAIC. Provider restrictions remain provider-controlled; no DRM/paywall/ad circumvention or unauthorized stream extraction.

## Current implementation

- Multi-module Android project: `:app`, `:core:media`, `:core:library`, `:core:design`.
- Compose Home / Library / Player UI and animated visual system.
- MediaStore audio catalog with read-only indexing.
- Storage Access Framework open-file playback.
- Media3 ExoPlayer in `MediaSessionService`, with controller connection and queue playback.
- Provider-neutral `MediaSourceAdapter` and explicit capability model.
- Source-level tests and `tools/verify_source.py`.
- GitHub import/build workflow delivered separately and copied into the source tree.

## Verification status

- Source verifier: must be run during handoff package validation.
- Python workflow tests and YAML/Bash syntax checks: must be run during handoff package validation.
- Gradle Android build: **not run in this container** because no Android SDK/Gradle installation is present and outbound dependency access is unavailable. GitHub Actions is configured to perform the authoritative build.
- APK: **not yet verified or delivered**. A successful CI run is required; actual Redmi device validation remains a separate acceptance gate.

## Next engineering focus

1. Run bootstrap import on GitHub; it generates and verifies the Gradle wrapper, then runs the authoritative build.
2. Fix any compile/lint/test issue reported by the first CI run before starting Phase 2.
3. On Redmi Note 12 Pro 5G, verify screen-off playback, notification/lock-screen controls, headset/Bluetooth actions, audio focus and battery behavior.
4. Retain the CI-generated Gradle wrapper and pinned distribution checksum from the first successful import; change the pinned toolchain only through an ADR.
5. Begin Phase 2 only after Phase 1 exit criteria are signed off.

## Session rule

Always read this file and `docs/TASKS.md` before changing code. Update this file, the task board, `docs/CHANGELOG.md` and an ADR whenever a locked architectural decision changes. Never replace the whole codebase with a small prototype or an unrelated project.
