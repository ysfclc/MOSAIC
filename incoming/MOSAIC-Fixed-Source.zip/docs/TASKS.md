# MOSAIC task board

**Source of truth:** this file. Update task status in the same commit as code changes.  
Status values: `DONE`, `IN PROGRESS`, `BLOCKED`, `TODO`, `PARKED`.

## Phase 1 — Native foundation and local playback

| ID | Task | Status | Verification / note |
|---|---|---|---|
| P1-001 | Establish modular Gradle project and package identity | DONE | `:app`, `:core:media`, `:core:library`, `:core:design` |
| P1-002 | Lock Media Core / adapter / capability contracts | DONE | `docs/ARCHITECTURE.md`, `core/media` |
| P1-003 | Create MOSAIC dark design system and motion language | DONE | Compose theme, ambient glow, animated artwork and transitions |
| P1-004 | Build Home / Library / Player navigation and states | DONE | `app/src/main/java/.../MosaicApp.kt` |
| P1-005 | Implement read-only MediaStore audio catalog | DONE | `MediaStoreCatalog`; permission failure handled |
| P1-006 | Implement Storage Access Framework open-file playback | DONE | `OpenDocument` path; persist URI read permission where offered |
| P1-007 | Implement Media3 foreground playback service and session | DONE | `PlaybackService`, manifest service declaration |
| P1-008 | Connect UI via MediaController and expose queue controls | DONE | `PlaybackConnection`, player and mini-player |
| P1-009 | Add capability tests for source contract | DONE | `SourceCapabilitiesTest` |
| P1-010 | Add source verifier and ZIP-import CI workflow | IN PROGRESS | Local workflow/static verification required; remote build still pending |
| P1-011 | Generate official Gradle wrapper + distribution checksum | TODO | No Gradle distribution in authoring container; CI currently pins Gradle 9.3.1 |
| P1-012 | Run GitHub Actions debug build, lint and unit tests | IN PROGRESS | Vercel sandbox build, tests, lint and APK passed; GitHub import workflow run remains pending |
| P1-013 | Install and validate on Redmi Note 12 Pro 5G | TODO | Device acceptance: screen-off, lock screen, Bluetooth, audio focus |
| P1-014 | Verify import, app startup, file picker and local indexing on device | TODO | Device acceptance |
| P1-015 | Align CI with the published Android 37 SDK platform package | DONE | Workflow installs `platforms;android-37.2`; compileSdk remains 37 |
| P1-016 | Propagate playback revision into the artwork composable | DONE | PlayerScreen forwards revision to PlayerArtwork; regression test added |

## Phase 2 — Durable library and source foundations

| ID | Task | Status |
|---|---|---|
| P2-001 | Design Room entities, DAO and migration policy | TODO |
| P2-002 | Persist playback history, queue and resume positions | TODO |
| P2-003 | Add incremental MediaStore sync and stable identity rules | TODO |
| P2-004 | Add collections, bookmarks, sorting and filters | TODO |
| P2-005 | Add RSS podcast adapter | TODO |
| P2-006 | Add internet radio adapter and reconnect policy | TODO |
| P2-007 | Add offline/download manager for permitted sources | TODO |
| P2-008 | Add sleep timer and playback speed controls | TODO |
| P2-009 | Add Room migrations and process-death tests | TODO |
| P2-010 | Add reduced-motion/accessibility settings and robust dynamic text states | TODO |
| P2-011 | Add a native video surface, orientation handling and picture-in-picture | TODO |

## Phase 3 — Browser and capture

| ID | Task | Status |
|---|---|---|
| P3-001 | Browser engine contract and WebView baseline | TODO |
| P3-002 | Tabs, bookmarks, download handling and session persistence | TODO |
| P3-003 | Android share target and capture inbox | TODO |
| P3-004 | Media element detection and source capability reporting | TODO |
| P3-005 | Permitted browser-to-native playback handoff | TODO |
| P3-006 | Multi-site browser/player test matrix | TODO |

## Phase 4 — Official provider adapters

| ID | Task | Status |
|---|---|---|
| P4-001 | YouTube official API / embedded player policy assessment | TODO |
| P4-002 | Spotify App Remote / official integration assessment | TODO |
| P4-003 | Explicit provider auth, permissions and adapter UX | TODO |
| P4-004 | Capability matrix and provider regression tests | TODO |

## Phase 5 — Local intelligence

| ID | Task | Status |
|---|---|---|
| P5-001 | On-device transcription benchmark on target device | TODO |
| P5-002 | Timestamped transcript schema and pipeline | TODO |
| P5-003 | Language detection / translation workflow | TODO |
| P5-004 | Chapters, summaries and evidence-backed highlights | TODO |
| P5-005 | Semantic search and processing job queue | TODO |

## Phase 6 — Automation / backup / ecosystem

| ID | Task | Status |
|---|---|---|
| P6-001 | Rule engine for imports and processing | TODO |
| P6-002 | Export manifest and portable library format | TODO |
| P6-003 | Manual external backup and restore verification | TODO |
| P6-004 | Optional cross-device sync / self-host feasibility | TODO |
| P6-005 | Android Auto, casting and adapter SDK assessments | TODO |

## Current blockers

- Remote `ysfclc/mosaic` repository must be created once by the user.
- First CI build must verify dependencies, Gradle DSL and Android compilation.
- APK must be installed and exercised on the target Redmi device before Phase 1 is considered complete.
