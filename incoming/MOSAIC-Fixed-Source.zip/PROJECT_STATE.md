# MOSAIC project state — session handoff

**Project:** MOSAIC / Personal Media OS  
**Repository:** ysfclc/MOSAIC  
**Branch:** main (source ZIP fetched from the repository; no GitHub commit made by this task)  
**Current phase:** 1 — Native foundation and local playback  
**Architecture status:** LOCKED baseline; changes require an ADR in docs/DECISIONS.md  
**Source snapshot:** 2026-11-04 — corrected Phase 1 build handoff

## Product contract

One native Android experience over multiple legitimate media sources. Local-first, provider-independent, no mandatory account, no mandatory subscription for core local playback, and no ads inserted by MOSAIC. Provider restrictions remain provider-controlled; no DRM/paywall/ad circumvention or unauthorized stream extraction.

## Current implementation

- Multi-module Android project: :app, :core:media, :core:library, :core:design.
- Compose Home / Library / Player UI and animated visual system.
- MediaStore audio catalog with read-only indexing; Storage Access Framework open-file playback.
- Media3 ExoPlayer in MediaSessionService, with controller connection and queue playback.
- Provider-neutral MediaSourceAdapter and explicit capability model.
- PlayerArtwork now receives the playback revision from PlayerScreen; the SIGNAL label no longer references an out-of-scope value.
- CI installs the published Android SDK API 37 platform package platforms;android-37.2; compileSdk = 37, targetSdk = 36, minSdk = 26 remain unchanged.

## Verification — 2026-11-04

- Source verifier: PASS (python3 tools/verify_source.py).
- Python contract tests: 8/8 PASS (python3 -m unittest discover -s tools/tests -v). Includes regression coverage for the artwork revision parameter and SDK package name.
- Android build: PASS in the Vercel sandbox with Java 17, Gradle 9.3.1, Android SDK Platform 37.2 and Build Tools 36.0.0.
- Gradle tasks: :core:media:testDebugUnitTest, :app:testDebugUnitTest, :app:lintDebug, :app:assembleDebug — BUILD SUCCESSFUL.
- Debug APK: app/build/outputs/apk/debug/app-debug.apk (22 MB), SHA-256 a79b047f766b754b3eb097ec1c31d9fd4bcd0dd3c3ae603a3d4b487174d48078.
- APK metadata verified: application ID com.ysfclc.mosaic, version 0.1.0-phase1, compile SDK 37, target SDK 36, min SDK 26.
- Android Lint completed successfully with existing warnings (target SDK 36, dependency update suggestions, exported media service permission warning, and deprecated backup configuration). These warnings were not suppressed or silently changed.
- The first sandbox Gradle attempt lost its daemon under memory pressure. A second build completed successfully, followed by a clean cached/offline verification pass that also completed successfully.

## Remaining acceptance gates

- P1-010: run the repository ZIP-import workflow end-to-end on GitHub.
- P1-011: generate and commit the Gradle wrapper and pinned wrapper checksum through the first successful import workflow.
- P1-012: local Android build is verified; GitHub Actions import/build result is still pending.
- P1-013 and P1-014: physical Redmi Note 12 Pro 5G acceptance remains pending (screen-off playback, notification, lock screen, headset/Bluetooth, audio focus, app startup, permissions, SAF, and local indexing).
- Phase 2 must remain parked until Phase 1 device acceptance is completed.

## Build record

See notes/builds/2026-11-04-vercel-build.md for sandbox/toolchain details, Gradle outcomes, APK checksum, lint warnings, and exact acceptance limits.

## Handoff integrity

- Source was fetched from incoming/MOSAIC-Phase-1-Repository.zip at GitHub blob e45cd6b123cca7b8376364518907fbbd3d43a0d8.
- The corrected source ZIP preserves the app source, project documentation, and GitHub workflow. Generated build caches and build outputs are excluded from the source ZIP; the APK is handed off separately.
- This task did not push or commit changes to GitHub. Upload the resulting full-source ZIP as incoming/mosaic.zip to invoke the repository's canonical importer.
- No claim of physical-device validation is made.
