package com.ysfclc.mosaic.ui.media

/**
 * Minimal IPv4/UDP DNS packet codec for the DNS-only MOSAIC VPN route.
 * It deliberately does not parse or inspect application payloads.
 */
internal object DnsPacketCodec {
    data class Request(
        val sourceAddress: ByteArray,
        val destinationAddress: ByteArray,
        val identification: Int,
        val sourcePort: Int,
        val destinationPort: Int,
        val dnsMessage: ByteArray,
    )

    fun parseIpv4Dns(packet: ByteArray, length: Int): Request? {
        if (length < 28 || length > packet.size) return null
        val version = (packet[0].toInt() ushr 4) and 0x0F
        val headerLength = (packet[0].toInt() and 0x0F) * 4
        if (version != 4 || headerLength < 20 || length < headerLength + 8) return null
        if ((packet[9].toInt() and 0xFF) != 17) return null // UDP only

        val totalLength = readU16(packet, 2)
        if (totalLength < headerLength + 8 || totalLength > length) return null
        val fragment = readU16(packet, 6)
        if ((fragment and 0x3FFF) != 0) return null // offset or more-fragments flag; fragmented DNS is not handled

        val udpOffset = headerLength
        val sourcePort = readU16(packet, udpOffset)
        val destinationPort = readU16(packet, udpOffset + 2)
        if (destinationPort != 53) return null
        val udpLength = readU16(packet, udpOffset + 4)
        if (udpLength < 20 || udpOffset + udpLength > totalLength) return null

        val dnsLength = udpLength - 8
        if (dnsLength < 12) return null
        return Request(
            sourceAddress = packet.copyOfRange(12, 16),
            destinationAddress = packet.copyOfRange(16, 20),
            identification = readU16(packet, 4),
            sourcePort = sourcePort,
            destinationPort = destinationPort,
            dnsMessage = packet.copyOfRange(udpOffset + 8, udpOffset + 8 + dnsLength),
        )
    }

    fun buildIpv4Response(request: Request, dnsMessage: ByteArray): ByteArray =
        buildIpv4ResponsePackets(request, dnsMessage).single()

    /**
     * Builds IPv4 fragments when an upstream DNS response exceeds the TUN MTU.
     * The first fragment contains the UDP header; later fragments continue its payload.
     */
    fun buildIpv4ResponsePackets(
        request: Request,
        dnsMessage: ByteArray,
        mtu: Int = DEFAULT_MTU,
    ): List<ByteArray> {
        require(request.sourceAddress.size == 4 && request.destinationAddress.size == 4)
        require(request.destinationPort == 53)
        require(dnsMessage.size >= 12)
        require(mtu >= IPV4_HEADER_SIZE + UDP_HEADER_SIZE + 12)

        val udpLength = UDP_HEADER_SIZE + dnsMessage.size
        require(udpLength <= 0xFFFF)
        val udpDatagram = ByteArray(udpLength)
        writeU16(udpDatagram, 0, request.destinationPort)
        writeU16(udpDatagram, 2, request.sourcePort)
        writeU16(udpDatagram, 4, udpLength)
        writeU16(udpDatagram, 6, 0) // IPv4 permits an omitted UDP checksum.
        dnsMessage.copyInto(udpDatagram, UDP_HEADER_SIZE)

        val maxFragmentPayload = ((mtu - IPV4_HEADER_SIZE) / 8) * 8
        val packets = mutableListOf<ByteArray>()
        var offset = 0
        while (offset < udpDatagram.size) {
            val fragmentLength = minOf(maxFragmentPayload, udpDatagram.size - offset)
            val hasMore = offset + fragmentLength < udpDatagram.size
            val packet = ByteArray(IPV4_HEADER_SIZE + fragmentLength)
            packet[0] = 0x45
            writeU16(packet, 2, packet.size)
            writeU16(packet, 4, request.identification)
            val flagsAndOffset = (offset / 8) or (if (hasMore) MORE_FRAGMENTS_FLAG else 0)
            writeU16(packet, 6, flagsAndOffset)
            packet[8] = 64
            packet[9] = 17
            request.destinationAddress.copyInto(packet, 12)
            request.sourceAddress.copyInto(packet, 16)
            writeU16(packet, 10, ipv4Checksum(packet, 0, IPV4_HEADER_SIZE))
            udpDatagram.copyInto(packet, IPV4_HEADER_SIZE, offset, offset + fragmentLength)
            packets += packet
            offset += fragmentLength
        }
        return packets
    }

    fun errorResponse(query: ByteArray, responseCode: Int): ByteArray? {
        if (query.size < 12 || responseCode !in 0..15) return null
        if (readU16(query, 4) < 1) return null

        val questionEnd = firstQuestionEnd(query) ?: return null
        val response = query.copyOfRange(0, questionEnd)
        response[2] = (query[2].toInt() or 0x80).toByte() // response bit; preserve RD/opcode
        response[3] = ((query[3].toInt() and 0xF0) or responseCode).toByte()
        writeU16(response, 4, 1) // the first question is retained
        writeU16(response, 6, 0) // answers
        writeU16(response, 8, 0) // authority
        writeU16(response, 10, 0) // additional / EDNS
        return response
    }

    private fun firstQuestionEnd(message: ByteArray): Int? {
        var offset = 12
        var labels = 0
        while (offset < message.size) {
            val length = message[offset].toInt() and 0xFF
            if (length == 0) {
                offset++
                break
            }
            if ((length and 0xC0) == 0xC0) {
                if (offset + 1 >= message.size) return null
                offset += 2
                break
            }
            if (length > 63 || offset + 1 + length > message.size) return null
            offset += 1 + length
            labels++
            if (labels > 127) return null
        }
        if (offset + 4 > message.size) return null
        return offset + 4
    }

    private fun ipv4Checksum(bytes: ByteArray, start: Int, size: Int): Int {
        var sum = 0L
        var offset = start
        while (offset < start + size) {
            sum += (((bytes[offset].toInt() and 0xFF) shl 8) or (bytes[offset + 1].toInt() and 0xFF)).toLong()
            offset += 2
        }
        while ((sum ushr 16) != 0L) sum = (sum and 0xFFFFL) + (sum ushr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun readU16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xFF) shl 8) or (bytes[offset + 1].toInt() and 0xFF)

    private fun writeU16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 8).toByte()
        bytes[offset + 1] = value.toByte()
    }

    private const val IPV4_HEADER_SIZE = 20
    private const val UDP_HEADER_SIZE = 8
    private const val DEFAULT_MTU = 1500
    private const val MORE_FRAGMENTS_FLAG = 0x2000
}
