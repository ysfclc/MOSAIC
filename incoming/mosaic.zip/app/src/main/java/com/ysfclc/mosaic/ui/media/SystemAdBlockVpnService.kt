package com.ysfclc.mosaic.ui.media

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.ysfclc.mosaic.MainActivity
import com.ysfclc.mosaic.R
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * DNS-only local VPN. Only packets addressed to the private DNS endpoint are routed
 * into this TUN interface; ordinary application traffic never passes through MOSAIC.
 * DNS messages are forwarded over authenticated DNS-over-TLS to AdGuard Public DNS.
 */
class SystemAdBlockVpnService : VpnService() {
    private var tunnel: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    @Volatile
    private var resolver: AdGuardDnsOverTls? = null
    private val stopping = AtomicBoolean(false)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startShieldForeground()
        if (tunnel == null) {
            val established = try {
                Builder()
                    .setSession("MOSAIC Device Shield")
                    .setMtu(1500)
                    // /30 keeps both the interface address (.1) and DNS endpoint (.2) in-range.
                    .addAddress(LOCAL_TUN_ADDRESS, 30)
                    .addDnsServer(LOCAL_DNS_ADDRESS)
                    .addRoute(LOCAL_DNS_ADDRESS, 32)
                    .establish()
            } catch (exception: Exception) {
                Log.e(TAG, "Could not establish the DNS filter tunnel", exception)
                null
            }

            if (established == null) {
                statusMessage = "Android could not establish the VPN. Check VPN permission and other active VPNs."
                isActive = false
                stopShield()
                stopSelf(startId)
                return START_NOT_STICKY
            }

            tunnel = established
            stopping.set(false)
            statusMessage = null
            resolver = AdGuardDnsOverTls(this) { message -> statusMessage = message }
            isActive = true
            startPacketLoop(established)
        }
        return START_STICKY
    }

    override fun onRevoke() {
        statusMessage = "Android revoked the VPN permission. Enable the Shield again to resume filtering."
        stopShield()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopShield()
        super.onDestroy()
    }

    private fun startShieldForeground() {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mosaic)
            .setContentTitle("MOSAIC Shield is active")
            .setContentText("Encrypted DNS filtering for app traffic")
            .setContentIntent(openApp)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startPacketLoop(descriptor: ParcelFileDescriptor) {
        worker = Thread({
            val packet = ByteArray(32 * 1024)
            try {
                // Both streams refer to the same TUN descriptor: reads deliver DNS requests;
                // writes inject the corresponding replies back into Android's resolver.
                val input = FileInputStream(descriptor.fileDescriptor)
                val output = FileOutputStream(descriptor.fileDescriptor)
                while (!stopping.get()) {
                    val length = input.read(packet)
                    if (length <= 0) continue
                    val request = DnsPacketCodec.parseIpv4Dns(packet, length) ?: continue
                    val dnsReply = resolver?.resolve(request.dnsMessage)
                        ?: DnsPacketCodec.errorResponse(request.dnsMessage, SERVFAIL_RCODE)
                        ?: continue
                    val responsePackets = runCatching {
                        DnsPacketCodec.buildIpv4ResponsePackets(request, dnsReply)
                    }.getOrNull() ?: continue
                    responsePackets.forEach { output.write(it) }
                    output.flush()
                }
            } catch (exception: IOException) {
                if (!stopping.get()) {
                    statusMessage = "The DNS tunnel stopped unexpectedly. Disable and re-enable the Shield."
                    isActive = false
                    Log.w(TAG, "DNS tunnel stopped after I/O error", exception)
                    stopSelf()
                }
            } catch (exception: Exception) {
                if (!stopping.get()) {
                    statusMessage = "The DNS tunnel encountered an unexpected error. Disable and re-enable the Shield."
                    isActive = false
                    Log.e(TAG, "DNS tunnel failed", exception)
                    stopSelf()
                }
            }
        }, "mosaic-dns-filter").apply {
            isDaemon = true
            start()
        }
    }

    private fun stopShield() {
        if (!stopping.compareAndSet(false, true) && tunnel == null) return
        isActive = false
        runCatching { resolver?.close() }
        resolver = null
        runCatching { tunnel?.close() }
        tunnel = null
        worker?.interrupt()
        worker = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "MOSAIC Device Shield", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Status of MOSAIC device-wide DNS filtering"
                setShowBadge(false)
            },
        )
    }

    private class AdGuardDnsOverTls(
        private val vpnService: VpnService,
        private val onStatus: (String?) -> Unit,
    ) : AutoCloseable {
        @Volatile
        private var socket: SSLSocket? = null
        @Volatile
        private var closed = false

        @Synchronized
        fun resolve(query: ByteArray): ByteArray? {
            if (closed || query.size < 12 || query.size > MAX_DNS_MESSAGE) return null
            return try {
                val connection = connectedSocket()
                val output = DataOutputStream(connection.outputStream)
                output.writeShort(query.size)
                output.write(query)
                output.flush()

                val input = DataInputStream(connection.inputStream)
                val responseLength = input.readUnsignedShort()
                if (responseLength < 12 || responseLength > MAX_DNS_MESSAGE) throw IOException("Invalid DNS response length")
                val response = ByteArray(responseLength)
                input.readFully(response)
                if (response[0] != query[0] || response[1] != query[1]) {
                    throw IOException("DNS response ID did not match the request")
                }
                if ((response[2].toInt() and 0x80) == 0) {
                    throw IOException("Upstream message was not a DNS response")
                }
                onStatus(null)
                response
            } catch (exception: Exception) {
                closeSocket()
                if (!closed) onStatus("AdGuard DNS is unreachable. Check your connection; DNS requests may fail until it reconnects.")
                Log.w(TAG, "Encrypted DNS upstream unavailable", exception)
                null
            }
        }

        private fun connectedSocket(): SSLSocket {
            if (closed) throw IOException("DNS resolver is closed")
            socket?.takeIf { it.isConnected && !it.isClosed && it.isInputShutdown.not() }?.let { return it }
            closeSocket()

            var lastError: Exception? = null
            for (address in UPSTREAM_IPS) {
                if (closed) throw IOException("DNS resolver is closed")
                var rawSocket: Socket? = null
                try {
                    val upstreamSocket = Socket()
                    rawSocket = upstreamSocket
                    upstreamSocket.soTimeout = SOCKET_TIMEOUT_MS
                    if (!vpnService.protect(upstreamSocket)) throw IOException("Could not protect upstream DNS socket")
                    upstreamSocket.connect(InetSocketAddress(InetAddress.getByName(address), TLS_PORT), CONNECT_TIMEOUT_MS)
                    val tlsSocket = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                        .createSocket(upstreamSocket, TLS_HOST, TLS_PORT, true) as SSLSocket
                    tlsSocket.soTimeout = SOCKET_TIMEOUT_MS
                    tlsSocket.sslParameters = tlsSocket.sslParameters.apply {
                        endpointIdentificationAlgorithm = "HTTPS"
                        serverNames = listOf(SNIHostName(TLS_HOST))
                    }
                    tlsSocket.startHandshake()
                    if (closed) {
                        tlsSocket.close()
                        throw IOException("DNS resolver was closed during connection setup")
                    }
                    socket = tlsSocket
                    return tlsSocket
                } catch (exception: Exception) {
                    runCatching { rawSocket?.close() }
                    lastError = exception
                }
            }
            throw lastError ?: IOException("No DNS-over-TLS upstream available")
        }

        // Do not synchronize close(): it must be able to interrupt a resolver read that is
        // blocked while the service is being stopped, rather than blocking the service thread.
        override fun close() {
            closed = true
            closeSocket()
        }

        private fun closeSocket() {
            val current = socket
            socket = null
            runCatching { current?.close() }
        }

        companion object {
            private const val TLS_HOST = "dns.adguard-dns.com"
            private const val TLS_PORT = 853
            private const val CONNECT_TIMEOUT_MS = 4_000
            private const val SOCKET_TIMEOUT_MS = 6_000
            private const val MAX_DNS_MESSAGE = 4_096
            private val UPSTREAM_IPS = listOf(
                "94.140.14.14",
                "94.140.15.15",
                "2a10:50c0::ad1:ff",
                "2a10:50c0::ad2:ff",
            )
        }
    }

    companion object {
        private const val TAG = "MosaicDnsShield"
        private const val CHANNEL_ID = "mosaic_dns_shield"
        private const val NOTIFICATION_ID = 4201
        private const val LOCAL_TUN_ADDRESS = "10.111.0.1"
        private const val LOCAL_DNS_ADDRESS = "10.111.0.2"
        private const val SERVFAIL_RCODE = 2

        @Volatile
        private var isActive: Boolean = false

        @Volatile
        private var statusMessage: String? = null

        fun isRunning(): Boolean = isActive

        fun statusMessage(): String? = statusMessage

        fun start(context: Context) {
            val intent = Intent(context, SystemAdBlockVpnService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            statusMessage = null
            context.stopService(Intent(context, SystemAdBlockVpnService::class.java))
        }
    }
}
