package com.ysfclc.mosaic.ui.media

import android.content.ComponentName
import android.content.Context
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Notification listener used only as Android's documented gate to active media sessions. */
class MosaicMediaNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) = Unit
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = Unit
}

data class ExternalMediaSession(
    val packageName: String,
    val appName: String,
    val title: String,
    val artist: String,
    val isPlaying: Boolean,
    val canPlay: Boolean,
    val canPause: Boolean,
    val canSkipNext: Boolean,
    val canSkipPrevious: Boolean,
    private val controller: MediaController,
) {
    val canTogglePlayback: Boolean
        get() = if (isPlaying) canPause else canPlay

    fun togglePlayback() {
        if (isPlaying && canPause) controller.transportControls.pause()
        else if (!isPlaying && canPlay) controller.transportControls.play()
    }

    fun skipNext() {
        if (canSkipNext) controller.transportControls.skipToNext()
    }

    fun skipPrevious() {
        if (canSkipPrevious) controller.transportControls.skipToPrevious()
    }
}

object ExternalMediaSessionBridge {
    fun hasNotificationAccess(context: Context): Boolean {
        val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
        val expected = ComponentName(context, MosaicMediaNotificationListener::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == expected }
    }

    fun activeSessions(context: Context): List<ExternalMediaSession> {
        if (!hasNotificationAccess(context)) return emptyList()
        val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val listener = ComponentName(context, MosaicMediaNotificationListener::class.java)
        return runCatching { manager.getActiveSessions(listener) }
            .getOrDefault(emptyList())
            .asSequence()
            .filter { it.packageName != context.packageName }
            .map { controller ->
                val metadata = controller.metadata
                val state = controller.playbackState
                val actions = state?.actions ?: 0L
                ExternalMediaSession(
                    packageName = controller.packageName,
                    appName = runCatching {
                        val info = context.packageManager.getApplicationInfo(controller.packageName, 0)
                        context.packageManager.getApplicationLabel(info).toString()
                    }.getOrDefault(controller.packageName),
                    title = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE).orEmpty().ifBlank { "Unknown media" },
                    artist = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST).orEmpty(),
                    isPlaying = state?.state == PlaybackState.STATE_PLAYING,
                    canPlay = (actions and (PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PLAY_PAUSE)) != 0L,
                    canPause = (actions and (PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE)) != 0L,
                    canSkipNext = (actions and PlaybackState.ACTION_SKIP_TO_NEXT) != 0L,
                    canSkipPrevious = (actions and PlaybackState.ACTION_SKIP_TO_PREVIOUS) != 0L,
                    controller = controller,
                )
            }
            .toList()
    }
}
