package com.ysfclc.mosaic.ui.media

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ysfclc.mosaic.core.design.MosaicPalette
import kotlinx.coroutines.delay

@Composable
fun SystemShieldScreen() {
    val context = LocalContext.current
    var shieldRunning by remember { mutableStateOf(SystemAdBlockVpnService.isRunning()) }
    var shieldStatusMessage by remember { mutableStateOf(SystemAdBlockVpnService.statusMessage()) }
    var notificationAccess by remember { mutableStateOf(ExternalMediaSessionBridge.hasNotificationAccess(context)) }
    var sessions by remember { mutableStateOf(emptyList<ExternalMediaSession>()) }

    val vpnConsent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) SystemAdBlockVpnService.start(context)
    }

    LaunchedEffect(Unit) {
        while (true) {
            shieldRunning = SystemAdBlockVpnService.isRunning()
            shieldStatusMessage = SystemAdBlockVpnService.statusMessage()
            notificationAccess = ExternalMediaSessionBridge.hasNotificationAccess(context)
            sessions = if (notificationAccess) ExternalMediaSessionBridge.activeSessions(context) else emptyList()
            delay(1_500)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("NETWORK + MEDIA CONTROL", color = MosaicPalette.Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
                Text("Your device.\nYour playback.", color = MosaicPalette.TextPrimary, fontSize = 30.sp, lineHeight = 34.sp, fontWeight = FontWeight.SemiBold)
                Text("One shield for DNS-level ad filtering, and one place to control media sessions that Android makes available.", color = MosaicPalette.TextSecondary, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18243A)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = MosaicPalette.Cyan.copy(alpha = .12f), shape = RoundedCornerShape(12.dp)) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = MosaicPalette.Cyan, modifier = Modifier.padding(10.dp))
                        }
                        Spacer(Modifier.weight(1f))
                        Text(
                            if (shieldRunning) "PROTECTION ACTIVE" else "PROTECTION PAUSED",
                            color = if (shieldRunning) MosaicPalette.Cyan else MosaicPalette.TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.1.sp,
                        )
                    }
                    Text("Device-wide DNS shield", color = MosaicPalette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Encrypted DNS-over-TLS through AdGuard Public DNS. Known ad, tracker and phishing domains can be blocked across apps that use Android's system DNS.",
                        color = MosaicPalette.TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 17.sp,
                    )
                    Button(
                        onClick = {
                            if (shieldRunning) {
                                SystemAdBlockVpnService.stop(context)
                            } else {
                                val consentIntent = VpnService.prepare(context)
                                if (consentIntent == null) SystemAdBlockVpnService.start(context) else vpnConsent.launch(consentIntent)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Text(if (shieldRunning) "Pause device shield" else "Enable device shield", fontWeight = FontWeight.SemiBold)
                    }
                    if (!shieldStatusMessage.isNullOrBlank()) {
                        Text(
                            shieldStatusMessage.orEmpty(),
                            color = Color(0xFFFFC27A),
                            fontSize = 9.sp,
                            lineHeight = 14.sp,
                        )
                    }
                    Text(
                        "DNS privacy: domain names from your DNS lookups are sent to AdGuard over encrypted TLS so it can resolve or block them. AdGuard can see the domains you request. MOSAIC does not install certificates or inspect page contents or audio.",
                        color = MosaicPalette.TextSecondary,
                        fontSize = 9.sp,
                        lineHeight = 14.sp,
                    )
                    Text(
                        "Android allows one active VPN at a time. Enabling this may replace another VPN profile. Apps using their own encrypted DNS or hard-coded endpoints may bypass DNS filtering. First-party, in-stream and sponsored-feed ads cannot be reliably removed by DNS.",
                        color = MosaicPalette.TextMuted,
                        fontSize = 9.sp,
                        lineHeight = 14.sp,
                    )
                }
            }
        }

        item {
            SectionTitle("CROSS-APP MEDIA", "Remote controls, not audio capture")
            Card(
                colors = CardDefaults.cardColors(containerColor = MosaicPalette.SurfaceGlass),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Android media sessions", color = MosaicPalette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "When an app publishes a media session, MOSAIC can show its track and send the actions that app exposes. The app itself still owns playback and decides whether it can continue in the background.",
                        color = MosaicPalette.TextSecondary,
                        fontSize = 10.sp,
                        lineHeight = 15.sp,
                    )
                    if (!notificationAccess) {
                        OutlinedButton(
                            onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(13.dp),
                        ) {
                            Text("Grant media-session access", fontSize = 11.sp)
                        }
                        Text("MOSAIC uses this permission to discover active media sessions. It does not read notification text.", color = MosaicPalette.TextMuted, fontSize = 9.sp, lineHeight = 14.sp)
                    } else if (sessions.isEmpty()) {
                        Text("No external media session is active. Start playback in another app and return here.", color = MosaicPalette.TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    }
                }
            }
        }

        itemsIndexed(sessions, key = { index, session -> "${session.packageName}:$index" }) { _, session ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xD91A2639)),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(session.appName, color = MosaicPalette.Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(session.packageName, color = MosaicPalette.TextMuted, fontSize = 7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(session.title, color = MosaicPalette.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(session.artist.ifBlank { if (session.isPlaying) "Playing" else "Not playing" }, color = MosaicPalette.TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (session.canSkipPrevious) IconButton(onClick = session::skipPrevious) { Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = MosaicPalette.TextSecondary) }
                        if (session.canTogglePlayback) IconButton(onClick = session::togglePlayback) {
                            Icon(if (session.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (session.isPlaying) "Pause" else "Play", tint = MosaicPalette.Cyan)
                        }
                        if (session.canSkipNext) IconButton(onClick = session::skipNext) { Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = MosaicPalette.TextSecondary) }
                        Spacer(Modifier.weight(1f))
                        Text(if (session.isPlaying) "LIVE SESSION" else "PAUSED", color = MosaicPalette.TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0x251B2940)), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("WHAT MOSAIC CAN'T FORCE", color = MosaicPalette.Violet, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    Text(
                        "A media controller cannot override an app's background-playback rules. YouTube's official integration does not permit ad removal or hidden background playback. Spotify remains in the Spotify app; MOSAIC can only control its exposed session or use Spotify's authorized remote SDK where configured.",
                        color = MosaicPalette.TextSecondary,
                        fontSize = 10.sp,
                        lineHeight = 15.sp,
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(Modifier.padding(bottom = 9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, color = MosaicPalette.Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
        Text(subtitle, color = MosaicPalette.TextMuted, fontSize = 10.sp)
    }
}
