package com.ysfclc.mosaic.ui.media

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DnsPacketCodecTest {
    @Test
    fun parsesIpv4UdpDnsRequest() {
        val packet = dnsPacket()
        val parsed = DnsPacketCodec.parseIpv4Dns(packet, packet.size)

        assertNotNull(parsed)
        assertEquals(53124, parsed?.sourcePort)
        assertEquals(53, parsed?.destinationPort)
        assertArrayEquals(byteArrayOf(10, 0, 0, 7), parsed?.sourceAddress)
        assertArrayEquals(byteArrayOf(10, 111, 0, 2), parsed?.destinationAddress)
        assertEquals(1, readU16(parsed!!.dnsMessage, 4))
    }

    @Test
    fun rejectsNonDnsAndTruncatedPackets() {
        val packet = dnsPacket()
        assertNull(DnsPacketCodec.parseIpv4Dns(packet, packet.size - 3))
        packet[23] = 54 // destination UDP port becomes 54
        assertNull(DnsPacketCodec.parseIpv4Dns(packet, packet.size))
    }

    @Test
    fun rejectsFragmentedDnsPackets() {
        val packet = dnsPacket()
        packet[6] = 0x20 // MF flag: first fragment of a fragmented IPv4 datagram
        packet[7] = 0x00
        assertNull(DnsPacketCodec.parseIpv4Dns(packet, packet.size))
    }

    @Test
    fun buildsReplyWithReversedIpAndUdpEndpoints() {
        val request = DnsPacketCodec.parseIpv4Dns(dnsPacket(), dnsPacket().size)!!
        val dnsReply = request.dnsMessage.copyOf().apply { this[2] = (this[2].toInt() or 0x80).toByte() }
        val reply = DnsPacketCodec.buildIpv4Response(request, dnsReply)

        assertEquals(0x45, reply[0].toInt() and 0xFF)
        assertEquals(0x5A5A, readU16(reply, 4))
        assertEquals(17, reply[9].toInt() and 0xFF)
        assertArrayEquals(byteArrayOf(10, 111, 0, 2), reply.copyOfRange(12, 16))
        assertArrayEquals(byteArrayOf(10, 0, 0, 7), reply.copyOfRange(16, 20))
        assertEquals(53, readU16(reply, 20))
        assertEquals(53124, readU16(reply, 22))
        assertEquals(0xFFFF, checksum(reply.copyOfRange(0, 20)))
    }

    @Test
    fun fragmentsLargeDnsResponsesToRespectTunMtu() {
        val request = DnsPacketCodec.parseIpv4Dns(dnsPacket(), dnsPacket().size)!!
        val dnsReply = ByteArray(3_500).apply {
            this[0] = request.dnsMessage[0]
            this[1] = request.dnsMessage[1]
            this[2] = 0x80.toByte()
        }
        val fragments = DnsPacketCodec.buildIpv4ResponsePackets(request, dnsReply)

        assertTrue(fragments.size > 1)
        assertTrue(fragments.all { it.size <= 1500 })
        assertEquals(0, readU16(fragments.first(), 6) and 0x1FFF)
        assertTrue((readU16(fragments.first(), 6) and 0x2000) != 0)
        assertEquals(185, readU16(fragments[1], 6) and 0x1FFF)
        assertEquals(0, readU16(fragments.last(), 6) and 0x2000)
    }

    @Test
    fun createsAnNxDomainResponseWithoutReturningEdnsRequestData() {
        val query = dnsPacket().let { DnsPacketCodec.parseIpv4Dns(it, it.size)!!.dnsMessage }
        val response = DnsPacketCodec.errorResponse(query, 3)

        assertNotNull(response)
        assertEquals(0x81, response!![2].toInt() and 0x81)
        assertEquals(3, response[3].toInt() and 0x0F)
        assertEquals(1, readU16(response, 4))
        assertEquals(0, readU16(response, 6))
        assertEquals(0, readU16(response, 8))
        assertEquals(0, readU16(response, 10))
        assertEquals(query.size - 11, response.size) // header + first question only
    }

    private fun dnsPacket(): ByteArray {
        val labels = listOf("example", "com")
        val name = labels.flatMap { label -> listOf(label.length.toByte()) + label.toByteArray().toList() }.toByteArray() + byteArrayOf(0)
        val dns = ByteArray(12 + name.size + 4 + 11)
        dns[0] = 0x12
        dns[1] = 0x34
        dns[2] = 0x01 // recursion desired
        dns[5] = 0x01 // one question
        var cursor = 12
        name.copyInto(dns, cursor)
        cursor += name.size
        dns[cursor++] = 0x00
        dns[cursor++] = 0x01 // A
        dns[cursor++] = 0x00
        dns[cursor++] = 0x01 // IN
        dns[cursor++] = 0x00 // root owner name
        dns[cursor++] = 0x00
        dns[cursor++] = 0x29 // OPT pseudo-type
        dns[cursor++] = 0x10
        dns[cursor++] = 0x00 // advertised UDP payload size
        dns[cursor++] = 0x00
        dns[cursor++] = 0x00
        dns[cursor++] = 0x00 // extended RCODE + version
        dns[cursor++] = 0x00 // flags
        dns[cursor++] = 0x00
        dns[cursor] = 0x00 // RDLEN
        dns[11] = 0x01 // one additional EDNS record

        val packet = ByteArray(20 + 8 + dns.size)
        packet[0] = 0x45
        writeU16(packet, 2, packet.size)
        writeU16(packet, 4, 0x5A5A)
        packet[8] = 64
        packet[9] = 17
        byteArrayOf(10, 0, 0, 7).copyInto(packet, 12)
        byteArrayOf(10, 111, 0, 2).copyInto(packet, 16)
        writeU16(packet, 20, 53124)
        writeU16(packet, 22, 53)
        writeU16(packet, 24, 8 + dns.size)
        dns.copyInto(packet, 28)
        return packet
    }

    private fun readU16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xFF) shl 8) or (bytes[offset + 1].toInt() and 0xFF)

    private fun writeU16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 8).toByte()
        bytes[offset + 1] = value.toByte()
    }

    private fun checksum(header: ByteArray): Int {
        var sum = 0L
        var offset = 0
        while (offset < header.size) {
            sum += (((header[offset].toInt() and 0xFF) shl 8) or (header[offset + 1].toInt() and 0xFF)).toLong()
            offset += 2
        }
        while ((sum ushr 16) != 0L) sum = (sum and 0xFFFFL) + (sum ushr 16)
        return sum.toInt() and 0xFFFF
    }
}
