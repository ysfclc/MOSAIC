# MOSAIC — Personal Media OS

**Release line:** 0.3.0 · System Media Shield preview  
**Repository:** `ysfclc/MOSAIC`  
**Package:** `com.ysfclc.mosaic`  
**Target:** Android; first device acceptance target is Redmi Note 12 Pro 5G.

MOSAIC combines a native local-media player with two cross-app capabilities: a consent-based DNS shield and a control surface for Android media sessions. It is **not** a replacement YouTube/Spotify client, an audio interceptor or a universal ad-removal promise.

## What this version is for

- **Local playback:** index audio already on the device and play it through one Media3 session. This playback is owned by MOSAIC and is designed to continue after the screen turns off.
- **Device DNS shield:** an Android `VpnService` configures the system to send DNS requests to a private local tunnel address. MOSAIC forwards supported IPv4/UDP DNS queries over authenticated DNS-over-TLS to AdGuard Public DNS. AdGuard's resolver applies its ad/tracker domain lists. Ordinary app payloads do not pass through the tunnel.
- **Cross-app media controls:** after the user explicitly enables Android notification access, MOSAIC can discover exposed active media sessions and send play/pause/previous/next commands supported by those sessions. It never copies audio from another app.

## What the shield can and cannot do

The shield can block requests to known third-party advertising, tracking and phishing domains when an app uses Android's system DNS. That can reduce some ads and trackers in YouTube, Spotify, Facebook, Instagram and other apps, but it will not make every ad disappear.

It cannot reliably remove advertisements delivered from the same host as the content, in-stream video ads, sponsored feed posts, first-party promotions or ads embedded directly into an app's content. Apps that use their own DNS-over-HTTPS, hard-coded resolver addresses, direct IPs or other DNS paths may bypass it. This preview handles IPv4 UDP DNS packets; IPv6 DNS, DNS-over-TCP and broader compatibility require further work. Android Private DNS settings may also affect compatibility and must be tested on the target device.

The DNS resolver is AdGuard Public DNS. DNS hostnames are sent to that resolver over encrypted DNS-over-TLS; AdGuard can see the requested domain names. This is not a fully local blocklist engine. Enabling the VPN uses Android's single active VPN slot and may replace another VPN. The user must approve the VPN permission prompt.

## Background playback reality

MOSAIC's own Media3 player can continue supported local or otherwise authorized media in the background. For other apps, MOSAIC is a remote-control surface only when Android exposes an active media session and the user grants notification access. The source app retains ownership and decides whether it supports background playback.

- **YouTube:** MOSAIC cannot remove YouTube ads, extract its audio, or grant hidden/background playback to an account that does not already have that capability. The official YouTube app/player remains in control.
- **Spotify:** MOSAIC can control Spotify only through exposed Android media actions in this preview. A separate official Spotify App Remote integration is planned; Spotify continues to deliver and own the audio and background lifecycle.
- **Facebook / Instagram / other apps:** control is available only while the app exposes a media session and the action is advertised. Many social apps do not expose general video playback as a controllable media session. MOSAIC cannot force those apps to keep playing.

## Build environment

| Component | Pinned baseline |
|---|---|
| Android Gradle Plugin | 9.1.1 |
| Gradle | 9.3.1 |
| Java | 17 |
| Android compile SDK | 37 |
| Android target SDK | 36 |
| Minimum SDK | 26 |
| Media3 | 1.11.1 |

The app uses AGP 9 built-in Kotlin support and the separate Compose compiler plugin.

### Build in CI

Upload this complete source ZIP to `incoming/mosaic.zip` and run **Build MOSAIC Android APK**. The workflow validates the archive, runs `tools/verify_source.py`, Python contract tests, Android unit tests and lint, then assembles the debug APK. The expected APK path is `app/build/outputs/apk/debug/app-debug.apk`.

### First-run setup

1. Open **Library** and scan device audio, or open one audio file through the system picker.
2. Open **Player**, lock the screen and confirm MOSAIC-owned audio continues.
3. Open **Shield** and enable the device shield. Approve Android's VPN prompt. Check that normal browsing and the apps you use still resolve DNS.
4. On **Shield**, grant media-session access. Start playback in another app, return to MOSAIC and check whether that app exposes a controllable session.

## Project continuity

- `PROJECT_STATE.md` is the session handoff.
- `docs/TASKS.md` is the task source of truth.
- `docs/PHASES.md` defines release gates.
- `docs/DECISIONS.md` records superseding architecture decisions.
- `.github/workflows/build-apk.yml` is preserved by the ZIP importer; edit it separately only when intentionally changing CI.

## Verification status

The previous `0.2.0-browser-preview` CI build passed. This `0.3.0-system-shield-preview` source has not yet been built by GitHub Actions or tested on the Redmi device. The source verifier and 12 Python contract tests pass; the DNS packet codec's six JVM tests passed in a standalone Kotlin/JVM harness. Full Android VPN code has not yet been compiled by Gradle or CI and still requires physical-device validation. Do not treat a source ZIP as a validated APK.
