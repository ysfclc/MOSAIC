import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


class ProjectContractTests(unittest.TestCase):
    def test_architecture_declares_single_media_core(self):
        text = (ROOT / "docs/ARCHITECTURE.md").read_text(encoding="utf-8")
        self.assertIn("one app-wide `PlaybackService`", text)
        self.assertIn("MediaSourceAdapter", text)

    def test_provider_boundaries_are_explicit(self):
        text = (ROOT / "docs/DECISIONS.md").read_text(encoding="utf-8")
        self.assertIn("paywall bypass", text)
        self.assertIn("hidden audio extraction", text)
        self.assertIn("ADR-013", text)

    def test_workflow_is_present(self):
        self.assertTrue((ROOT / ".github/workflows/build-apk.yml").is_file())

    def test_player_artwork_receives_revision_from_player_screen(self):
        source = (ROOT / "app/src/main/java/com/ysfclc/mosaic/ui/MosaicApp.kt").read_text(encoding="utf-8")
        self.assertIn("PlayerArtwork(isPlaying = isPlaying, revision = revision)", source)
        self.assertIn("private fun PlayerArtwork(isPlaying: Boolean, revision: Int)", source)

    def test_workflow_installs_published_android_37_sdk_package(self):
        workflow = (ROOT / ".github/workflows/build-apk.yml").read_text(encoding="utf-8")
        self.assertIn('"platforms;android-37.2"', workflow)
        self.assertNotIn('"platforms;android-37"', workflow)

    def test_system_shield_is_a_dns_only_local_vpn(self):
        manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
        service = (ROOT / "app/src/main/java/com/ysfclc/mosaic/ui/media/SystemAdBlockVpnService.kt").read_text(encoding="utf-8")
        self.assertIn('android.permission.BIND_VPN_SERVICE', manifest)
        self.assertIn('android.permission.FOREGROUND_SERVICE_SYSTEM_EXEMPTED', manifest)
        self.assertIn('android:foregroundServiceType="systemExempted"', manifest)
        self.assertIn('FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED', service)
        self.assertIn('android.net.VpnService', manifest)
        self.assertIn('.addRoute(LOCAL_DNS_ADDRESS, 32)', service)
        self.assertIn('vpnService.protect(upstreamSocket)', service)
        self.assertIn('dns.adguard-dns.com', service)
        self.assertIn('TLS_PORT = 853', service)

    def test_dns_codec_rejects_fragmented_ipv4_and_only_handles_dns_udp(self):
        codec = (ROOT / "app/src/main/java/com/ysfclc/mosaic/ui/media/DnsPacketCodec.kt").read_text(encoding="utf-8")
        self.assertIn('!= 17', codec)
        self.assertIn('destinationPort != 53', codec)
        self.assertIn('fragment and 0x3FFF', codec)

    def test_external_media_controls_require_explicit_notification_access(self):
        manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
        bridge = (ROOT / "app/src/main/java/com/ysfclc/mosaic/ui/media/ExternalMediaSessionBridge.kt").read_text(encoding="utf-8")
        self.assertIn('android.permission.BIND_NOTIFICATION_LISTENER_SERVICE', manifest)
        self.assertIn('enabled_notification_listeners', bridge)
        self.assertIn('getActiveSessions(listener)', bridge)
        self.assertIn('ACTION_SKIP_TO_NEXT', bridge)

    def test_browser_is_not_a_navigation_destination(self):
        app = (ROOT / "app/src/main/java/com/ysfclc/mosaic/ui/MosaicApp.kt").read_text(encoding="utf-8")
        manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
        self.assertIn('Destination.SHIELD -> SystemShieldScreen()', app)
        self.assertNotIn('BrowserScreen', app)
        self.assertNotIn('android.intent.action.SEND', manifest)
        self.assertFalse((ROOT / 'app/src/main/java/com/ysfclc/mosaic/ui/browser/BrowserScreen.kt').exists())

    def test_playback_service_owns_audio_focus_and_wake_mode(self):
        source = (ROOT / "core/media/src/main/java/com/ysfclc/mosaic/core/media/PlaybackService.kt").read_text(encoding="utf-8")
        self.assertIn("setAudioAttributes(AudioAttributes.DEFAULT", source)
        self.assertIn("setWakeMode(C.WAKE_MODE_LOCAL)", source)

    def test_dns_privacy_and_provider_limitations_are_documented(self):
        product = (ROOT / "docs/PRODUCT_SPEC.md").read_text(encoding="utf-8")
        security = (ROOT / "docs/SECURITY.md").read_text(encoding="utf-8")
        self.assertIn("same-domain ads", product)
        self.assertIn("AdGuard Public DNS", product)
        self.assertIn("resolver can see queried hostnames", security)
        self.assertIn("cannot force", product)

    def test_dns_codec_test_file_exists(self):
        self.assertTrue((ROOT / "app/src/test/java/com/ysfclc/mosaic/ui/media/DnsPacketCodecTest.kt").is_file())


if __name__ == "__main__":
    unittest.main()
