#!/usr/bin/env python3
"""Structural verifier for the MOSAIC System Media Shield source snapshot."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/ysfclc/mosaic/MainActivity.kt",
    "app/src/main/java/com/ysfclc/mosaic/ui/MosaicApp.kt",
    "app/src/main/java/com/ysfclc/mosaic/ui/media/SystemShieldScreen.kt",
    "app/src/main/java/com/ysfclc/mosaic/ui/media/SystemAdBlockVpnService.kt",
    "app/src/main/java/com/ysfclc/mosaic/ui/media/DnsPacketCodec.kt",
    "app/src/main/java/com/ysfclc/mosaic/ui/media/ExternalMediaSessionBridge.kt",
    "app/src/test/java/com/ysfclc/mosaic/ui/media/DnsPacketCodecTest.kt",
    "core/media/build.gradle.kts",
    "core/library/build.gradle.kts",
    "core/design/build.gradle.kts",
    "docs/ARCHITECTURE.md",
    "docs/PRODUCT_SPEC.md",
    "docs/PHASES.md",
    "docs/TASKS.md",
    "docs/DECISIONS.md",
    "docs/SECURITY.md",
    "PROJECT_STATE.md",
]


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


missing = [path for path in REQUIRED if not (ROOT / path).is_file()]
if missing:
    fail("required project files missing: " + ", ".join(missing))

manifest_path = ROOT / "app/src/main/AndroidManifest.xml"
manifest = manifest_path.read_text(encoding="utf-8")
try:
    ET.fromstring(manifest)
except ET.ParseError as error:
    fail(f"Android manifest is not valid XML: {error}")

media_service = (ROOT / "core/media/src/main/java/com/ysfclc/mosaic/core/media/PlaybackService.kt").read_text(encoding="utf-8")
contract = (ROOT / "core/media/src/main/java/com/ysfclc/mosaic/core/media/MediaSource.kt").read_text(encoding="utf-8")
vpn_service = (ROOT / "app/src/main/java/com/ysfclc/mosaic/ui/media/SystemAdBlockVpnService.kt").read_text(encoding="utf-8")
codec = (ROOT / "app/src/main/java/com/ysfclc/mosaic/ui/media/DnsPacketCodec.kt").read_text(encoding="utf-8")
bridge = (ROOT / "app/src/main/java/com/ysfclc/mosaic/ui/media/ExternalMediaSessionBridge.kt").read_text(encoding="utf-8")
app = (ROOT / "app/src/main/java/com/ysfclc/mosaic/ui/MosaicApp.kt").read_text(encoding="utf-8")
shield_ui = (ROOT / "app/src/main/java/com/ysfclc/mosaic/ui/media/SystemShieldScreen.kt").read_text(encoding="utf-8")
workflow = ROOT / ".github/workflows/build-apk.yml"

checks = {
    "manifest is valid XML": True,
    "internet permission is declared for encrypted DNS": "android.permission.INTERNET" in manifest,
    "VPN system-exempted foreground permission is declared": "android.permission.FOREGROUND_SERVICE_SYSTEM_EXEMPTED" in manifest,
    "VPN service is protected by BIND_VPN_SERVICE": 'android:permission="android.permission.BIND_VPN_SERVICE"' in manifest,
    "Android VPN service action is registered": "android.net.VpnService" in manifest,
    "VPN foreground service uses the Android system-exempted type": 'android:foregroundServiceType="systemExempted"' in manifest and 'FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED' in vpn_service,
    "VPN routes only the local DNS endpoint": '.addRoute(LOCAL_DNS_ADDRESS, 32)' in vpn_service and '.addDnsServer(LOCAL_DNS_ADDRESS)' in vpn_service,
    "DNS address is within the TUN address prefix": '.addAddress(LOCAL_TUN_ADDRESS, 30)' in vpn_service,
    "upstream resolver is AdGuard DNS-over-TLS": 'dns.adguard-dns.com' in vpn_service and 'TLS_PORT = 853' in vpn_service,
    "upstream socket is protected from VPN recursion": 'vpnService.protect(upstreamSocket)' in vpn_service,
    "DNS uses encrypted TLS with hostname verification": 'endpointIdentificationAlgorithm = "HTTPS"' in vpn_service and 'startHandshake()' in vpn_service,
    "DNS packet codec accepts IPv4 UDP only": '!= 17' in codec and 'destinationPort != 53' in codec,
    "fragmented DNS is rejected": 'fragment and 0x3FFF' in codec,
    "external media controls require notification listener permission": 'android.permission.BIND_NOTIFICATION_LISTENER_SERVICE' in manifest,
    "external sessions are queried through Android MediaSessionManager": 'getActiveSessions(listener)' in bridge,
    "external actions are capability-gated": 'ACTION_SKIP_TO_NEXT' in bridge and 'ACTION_SKIP_TO_PREVIOUS' in bridge,
    "notification callbacks do not inspect notification text": 'onNotificationPosted(sbn: StatusBarNotification?) = Unit' in bridge,
    "Shield replaces Browser in main navigation": 'Destination.SHIELD -> SystemShieldScreen()' in app and 'BrowserScreen' not in app,
    "Shield UI contains real VPN consent flow": 'VpnService.prepare(context)' in shield_ui and 'StartActivityForResult' in shield_ui,
    "Shield UI requests notification access explicitly": 'ACTION_NOTIFICATION_LISTENER_SETTINGS' in shield_ui,
    "Browser-first source files are removed": not (ROOT / 'app/src/main/java/com/ysfclc/mosaic/ui/browser/BrowserScreen.kt').exists(),
    "Android share target is no longer registered": 'android.intent.action.SEND' not in manifest,
    "single MediaSessionService declaration": manifest.count('androidx.media3.session.MediaSessionService') == 1,
    "mediaPlayback foreground service type": 'android:foregroundServiceType="mediaPlayback"' in manifest,
    "screen-off wake lock permission": 'android.permission.WAKE_LOCK' in manifest,
    "local playback wake mode": 'setWakeMode(C.WAKE_MODE_LOCAL)' in media_service,
    "automatic audio focus": 'setAudioAttributes(AudioAttributes.DEFAULT' in media_service,
    "service is a MediaSessionService": 'MediaSessionService' in media_service,
    "source adapter contract": 'interface MediaSourceAdapter' in contract,
    "explicit source capabilities": 'class SourceCapabilities' in contract,
    "CI workflow template included": workflow.is_file(),
    "SDK platform pin matches published package": '"platforms;android-37.2"' in workflow.read_text(encoding='utf-8'),
    "Phase 1 picker remains audio-only until video UI exists": 'documentLauncher.launch(arrayOf("audio/*"))' in app,
    "YouTube background/ad limitation is documented": 'cannot remove YouTube ads' in (ROOT / 'README.md').read_text(encoding='utf-8') and 'hidden/background' in (ROOT / 'docs/PRODUCT_SPEC.md').read_text(encoding='utf-8'),
    "DNS same-domain and resolver bypass limits are documented": 'same-domain' in (ROOT / 'docs/PRODUCT_SPEC.md').read_text(encoding='utf-8') and 'app-specific DoH' in (ROOT / 'docs/PRODUCT_SPEC.md').read_text(encoding='utf-8'),
}

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
if failed:
    fail("one or more architecture invariants failed")

source_text = "\n".join(path.read_text(encoding="utf-8", errors="ignore") for path in ROOT.rglob("*.kt"))
if re.search(r"TODO\(phase1\)", source_text, flags=re.IGNORECASE):
    fail("found an unresolved Phase 1 placeholder marker")
if "ACTION_STOP" in vpn_service:
    fail("obsolete stop action remains in VPN service")
print("MOSAIC System Media Shield source structure verified. This is not a substitute for Gradle or device testing.")
