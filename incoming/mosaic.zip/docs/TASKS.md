# MOSAIC task board

Source of truth: this file. Update task status in the same commit as code changes.  
Status values: DONE, IN PROGRESS, BLOCKED, TODO, PARKED.

## Phase 1 — Native foundation and local playback

| ID | Task | Status | Verification / note |
|---|---|---|---|
| P1-001 | Establish modular Gradle project and package identity | DONE | :app, :core:media, :core:library, :core:design |
| P1-002 | Lock Media Core / adapter / capability contracts | DONE | docs/ARCHITECTURE.md, core/media |
| P1-003 | Create MOSAIC dark design system and motion language | DONE | Compose theme and motion primitives |
| P1-004 | Build Home / Library / Player navigation and states | DONE | MosaicApp.kt |
| P1-005 | Implement read-only MediaStore audio catalog | DONE | MediaStoreCatalog |
| P1-006 | Implement Storage Access Framework open-file playback | DONE | OpenDocument path and persisted read grant |
| P1-007 | Implement Media3 foreground playback service and session | DONE | PlaybackService and manifest declaration |
| P1-008 | Connect UI via MediaController and expose queue controls | DONE | PlaybackConnection, Player and mini-player |
| P1-009 | Add capability tests for source contract | DONE | SourceCapabilitiesTest |
| P1-010 | Add source verifier and ZIP-import CI workflow | DONE | Successful prior import/build run |
| P1-011 | Generate official Gradle wrapper + distribution checksum | DONE | Gradle 9.3.1 pinned |
| P1-012 | Run GitHub Actions debug build, lint and unit tests | DONE | Baseline run 41957296181 |
| P1-013 | Install and validate on Redmi Note 12 Pro 5G | TODO | Screen-off, lock screen, Bluetooth, audio focus |
| P1-014 | Verify startup, permissions, SAF and local indexing on device | TODO | Physical device acceptance |
| P1-015 | Align CI with published Android 37 SDK platform package | DONE | platforms;android-37.2 |
| P1-016 | Propagate playback revision into artwork composable | DONE | Regression test included |

## Phase 2 — Durable library and source foundations

| ID | Task | Status | Verification / note |
|---|---|---|---|
| P2-001 | Design Room entities, DAO and migration policy | TODO | Media identity, locations, collections, history and bookmarks |
| P2-002 | Persist playback history, queue and resume positions | TODO | Process-death and reboot tests |
| P2-003 | Add incremental MediaStore sync and stable identity rules | TODO | No duplicate copies; preserve original files |
| P2-004 | Add collections, bookmarks, sorting and filters | TODO | Durable library UX |
| P2-005 | Add RSS podcast adapter | TODO | Feed validation and resume |
| P2-006 | Add internet radio adapter | TODO | MIME/format detection, ICY metadata and reconnect |
| P2-007 | Add permitted-source download manager | TODO | Terms and capability checked per source |
| P2-008 | Add sleep timer and playback speed controls | TODO | Shared Media3 session |
| P2-009 | Add Room migrations and process-death tests | TODO | Migration coverage |
| P2-010 | Add reduced-motion/accessibility settings | TODO | Dynamic text and touch targets |
| P2-011 | Add native video surface and picture-in-picture | TODO | Only for permitted native sources |

## Phase 3 — System Media Shield and cross-app controls

| ID | Task | Status | Verification / note |
|---|---|---|---|
| P3-001 | Add consent-based DNS-only Android VPN service | IN PROGRESS | IPv4 UDP tunnel and AdGuard DoT resolver implemented; CI/device verification pending |
| P3-002 | Validate DNS packet codec and resolver failure behavior | IN PROGRESS | JVM codec tests added; compile/runtime tests pending |
| P3-003 | Add DNS diagnostics, block counters and optional per-app policy | TODO | Only report counts when measured; no synthetic metrics |
| P3-004 | Add external Android media-session control surface | IN PROGRESS | Metadata + supported play/pause/previous/next; device validation pending |
| P3-005 | Add shield compatibility matrix and recovery behavior | TODO | IPv6/TCP DNS transport, fragmented requests, Private DNS, app DoH and VPN conflicts |
| P3-006 | Keep native Media3 background playback stable with shield active | TODO | Redmi screen-off and network-change tests |

## Phase 4 — Official provider integrations

| ID | Task | Status | Verification / note |
|---|---|---|---|
| P4-001 | YouTube official metadata/visible playback capability review | TODO | No ad removal, extraction or hidden background player |
| P4-002 | Spotify Android App Remote integration | TODO | Client ID, redirect URI, explicit auth, current terms review |
| P4-003 | Provider capability UI and delegated-player state | IN PROGRESS | Android session surface exists; provider adapters pending |
| P4-004 | Provider policy and integration regression review | TODO | Re-check official policies before release |

## Phase 5 — Local intelligence

| ID | Task | Status |
|---|---|---|
| P5-001 | On-device transcription benchmark on target device | TODO |
| P5-002 | Timestamped transcript schema and pipeline | TODO |
| P5-003 | Language detection / translation workflow | TODO |
| P5-004 | Chapters, summaries and evidence-backed highlights | TODO |
| P5-005 | Semantic search and processing job queue | TODO |

## Phase 6 — Automation / backup / ecosystem

| ID | Task | Status |
|---|---|---|
| P6-001 | Rule engine for imports and processing | TODO |
| P6-002 | Export manifest and portable library format | TODO |
| P6-003 | Manual external backup and restore verification | TODO |
| P6-004 | Optional cross-device sync / self-host feasibility | TODO |
| P6-005 | Android Auto, casting and adapter SDK assessments | TODO |

## Current blockers

- This 0.3.0 source has not yet passed the GitHub Actions build after the System Shield changes.
- Android SDK/Gradle is not available offline in the working environment; CI must compile the Android code.
- Physical Redmi Note 12 Pro 5G testing is required for VPN DNS routing, AdGuard DoT reachability, Android Private DNS behavior, app compatibility, media sessions and screen-off playback.
- Initial VPN implementation covers IPv4 UDP DNS only. IPv6 DNS, DNS-over-TCP and app-specific resolver paths remain open compatibility work.
- No claim is made that YouTube/Spotify ads or any provider's background rules are bypassed.
