# Architecture decision record (ADR) log

This file is the canonical decision log. A decision marked **LOCKED** may only change through a superseding ADR with evidence and migration notes.

## ADR-001 — Native Android first (LOCKED)

- **Date:** 2026-10-30
- **Decision:** Kotlin + Jetpack Compose native Android app, initially targeting the Redmi Note 12 Pro 5G.
- **Why:** first-class Android playback service, storage permissions, media sessions, notifications, Bluetooth and file-picker integration.
- **Trade-off:** no iOS/desktop parity in early releases.

## ADR-002 — One Media Core and one primary player (LOCKED)

- **Decision:** one `MediaSessionService` owns the primary ExoPlayer and MediaSession; all UI/system controllers connect through MediaController.
- **Why:** consistent background lifecycle, notifications, lock-screen controls and external controls.
- **Rejected:** each feature/source creating its own player.
- **Migration rule:** source or remote playback adapters must hand permitted media into the shared session or remain on their source player with explicit capability reporting.

## ADR-003 — Source adapter + explicit capability contract (LOCKED)

- **Decision:** each source implements `MediaSourceAdapter` and declares actual capabilities.
- **Why:** providers differ; a universal interface must not imply universal rights or playback support.
- **Rejected:** provider-specific branches throughout screens and canonical library logic.

## ADR-004 — Local-first library; preserve original media (LOCKED)

- **Decision:** index existing local media without copying, moving or renaming files; use persisted SAF URI grants for individually selected items.
- **Why:** ownership, low storage use and preservation of the user's existing folder organization.
- **Later:** explicit user-directed import/copy workflows may be added with clear storage impact and reversible operations.

## ADR-005 — No mandatory backend, account or AI provider (LOCKED)

- **Decision:** core playback/library works locally and without sign-in. AI is optional and local-first.
- **Why:** user ownership, privacy and operating-cost constraints.
- **Rejected:** mandatory remote processing or a cloud account to unlock local capabilities.

## ADR-006 — Provider policy boundaries (LOCKED)

- **Decision:** no manipulation of provider players, DRM circumvention, paywall bypass, private API scraping or unauthorized audio extraction. Permitted third-party DNS ad/tracker domain filtering is separate from modifying provider playback and is governed by ADR-013.
- **Why:** legal resilience, reliability and avoidance of fragile integrations.
- **Trade-off:** certain third-party services cannot offer the same background or offline behavior as local/RSS media.

## ADR-007 — Modular Android Gradle project (LOCKED)

- **Decision:** start with `:app`, `:core:media`, `:core:library`, `:core:design`. New Gradle modules need a real ownership boundary and an ADR.
- **Why:** stable separation without over-fragmenting features.

## ADR-008 — Pinned CI toolchain and ZIP-based integration (LOCKED)

- **Decision:** CI pins Java 17, Gradle 9.3.1, AGP 9.1.1 and SDK package versions. One full-source ZIP is uploaded at `incoming/mosaic.zip`; the workflow validates, bootstraps a pinned Gradle Wrapper on the first successful import, builds and commits an upload note.
- **Why:** reproduce the Memo handoff method while protecting active workflows and source history.
- **Trade-off:** the remote repo must be created and the workflow installed once manually; subsequent source updates are ZIP-driven.

## ADR-009 — Phase One scope boundary (LOCKED)

- **Decision:** Phase 1 delivers native local indexing and background playback, not full provider parity. RSS/radio/provider adapters/AI/sync stay in the roadmap and contracts.
- **Why:** prove the highest-risk Android foundation before adding network and provider complexity.

## ADR-010 — WebView-scoped ad control (SUPERSEDED by ADR-013)

- Date: 2026-11-04.
- Historical decision (replaced 2026-11-05): the first preview used a conservative WebView-only request filter with provider exemptions. That implementation was removed because it did not meet the product requirement for app-wide protection.
- Supersedes ADR-006 only for permitted third-party request filtering on ordinary web pages. ADR-006 remains fully in force for YouTube/Spotify player ads, DRM, paywalls, private APIs and protected audiovisual streams.
- Why: the user requires meaningful ad control, but provider playback integrity and source ownership must remain intact.
- Limit: host/request filtering cannot remove all ads, first-party ads or in-stream ads and must never be marketed as universal ad removal.

## ADR-011 — Two-way media bridge with explicit playback ownership (LOCKED)

- Date: 2026-11-04.
- Decision: MOSAIC supports inbound capture/control (share intents, accessible media references, and explicitly authorized Android MediaSession control) and outbound handoff (Android open/share intents and MOSAIC's own MediaSession).
- Provider-owned playback remains provider-owned. Official SDKs may expose metadata and remote commands; they do not automatically grant MOSAIC the provider's audio stream or background-playback rights.
- Why: "vice versa" means media and control must move in both directions, not just import URLs into MOSAIC.
- Limit: no raw protected-stream interception, audio extraction, private API scraping or promise of one gapless queue across unrelated provider players.

## ADR-012 — YouTube and Spotify integration capability split (LOCKED)

- Date: 2026-11-04.
- YouTube: use permitted official metadata/search and standard visible embedded playback. Preserve provider ads/player UI. No background player, ad blocking, audio/video separation or offline copy.
- Spotify: use the official Android App Remote SDK, subject to current availability and terms, to connect to the installed Spotify app after user authorization. Display permitted player state and send supported commands. Spotify owns audio streaming and background lifecycle.
- Android external sessions: discover/control other active media sessions only through Android's supported access path and an explicit user-enabled NotificationListenerService; never silently request notification access.
- Why: this is the maximum honest integration surface supported by current provider and Android APIs. Re-evaluate against provider policy before release.

### Official references reviewed 2026-11-04

- YouTube Developer Policies: https://developers.google.com/youtube/terms/developer-policies-guide
- Spotify Android SDK (Beta): https://developer.spotify.com/documentation/android
- Spotify Android App Remote getting started: https://developer.spotify.com/documentation/android/tutorials/getting-started
- Android MediaSessionManager: https://developer.android.com/reference/android/media/session/MediaSessionManager


## ADR-013 — System-wide DNS shield and delegated media control (LOCKED)

- **Date:** 2026-11-05.
- **Supersedes:** ADR-010's Browser-first filtering strategy. ADR-006 remains in force for provider player modification, DRM/paywall bypass and unauthorized audio extraction.
- **Decision:** replace the toy Browser destination with a native Shield surface. The shield uses an explicit-consent Android `VpnService`, a DNS-only TUN route and authenticated DNS-over-TLS to AdGuard Public DNS. Only supported IPv4/UDP DNS requests are forwarded; normal app payloads do not traverse MOSAIC.
- **Decision:** put external Android media-session discovery and transport controls on the same Shield surface. Notification access is opt-in. The bridge reads session metadata and exposes only actions advertised by the session; it does not read notification text or capture audio.
- **Why:** the core user need is cross-app ad/tracker domain filtering and centralized control of existing media sessions, not a second browser.
- **Foreground service:** On Android 14+, the VPN service uses the `systemExempted` foreground type and matching permission for an active user-configured VPN.
- **Trade-offs:** Android has one active VPN slot; enabling MOSAIC may replace another VPN. DNS queries are sent to AdGuard over encrypted transport, so this is not a fully local resolver. Apps using their own DoH, hard-coded DNS or direct IP may bypass. The first implementation covers IPv4 UDP DNS only. Same-domain, in-stream and sponsored-feed ads remain outside DNS filtering.
- **Background rule:** an Android media session does not grant a source app background-playback rights. The source app retains stream ownership and decides lifecycle. MOSAIC's native Media3 player remains the background engine for local/permitted sources.
- **Rejected:** TLS interception, certificate installation, private API scraping, playback patching, hidden audio extraction and claiming universal ad removal.
- **Rollback:** disable/unregister the VpnService and remove the Shield destination; MOSAIC's local Media3 player and library remain unchanged.

### References reviewed 2026-11-05

- Android `VpnService`: https://developer.android.com/reference/android/net/VpnService
- Android VPN guide: https://developer.android.com/develop/connectivity/vpn
- Android `MediaSessionManager`: https://developer.android.com/reference/android/media/session/MediaSessionManager
- AdGuard Public DNS: https://adguard-dns.io/kb/general/dns-providers/
- YouTube Developer Policies: https://developers.google.com/youtube/terms/developer-policies-guide
- Spotify Android SDK: https://developer.spotify.com/documentation/android
