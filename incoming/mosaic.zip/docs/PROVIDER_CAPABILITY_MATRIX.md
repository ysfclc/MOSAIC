# MOSAIC provider and capability matrix

Capabilities must be evaluated for the current app, account, item and session. A control surface is not the same thing as playback ownership.

| Source | MOSAIC owns audio | MOSAIC background playback | DNS shield coverage | MOSAIC remote control | Limits |
|---|---|---|---|---|---|
| Local files | Yes | Yes | N/A | Yes, via MOSAIC MediaSession | Original files remain in place |
| Permitted RSS enclosures | Yes, when directly accessible | Yes | DNS layer only for host lookups | Yes, via MOSAIC MediaSession | Must respect source terms |
| Open internet radio | Yes, for supported formats | Yes | DNS layer only for host lookups | Yes, via MOSAIC MediaSession | Reconnect and codec support vary |
| YouTube installed app | No | Only as allowed by YouTube app/account | Third-party DNS domains only, best effort | Android MediaSession only if exposed | Cannot remove in-stream/same-domain ads, extract audio or grant background playback |
| Spotify installed app | No | Spotify app decides | Third-party DNS domains only, best effort | Android MediaSession when exposed; official App Remote planned | Spotify owns stream/background; DNS cannot remove same-host promotions reliably |
| Facebook / Instagram | No | Source app decides; many feed videos expose no general session | Third-party DNS domains only, best effort | Only if an active media session/actions are exposed | Sponsored posts and first-party ads cannot be reliably filtered; cannot force playback |
| Other media apps | No raw stream access | Source app decides | Third-party DNS domains only, best effort | Android MediaSession after opt-in, when exposed | No audio extraction or arbitrary player override |

## System DNS shield

- The local VPN configures a DNS server address inside a private TUN interface and routes only that DNS endpoint through the tunnel.
- DNS requests are forwarded over encrypted DNS-over-TLS to AdGuard Public DNS.
- The DNS provider can block known third-party ad/tracker domains using its resolver lists. The initial implementation supports IPv4/UDP only.
- App-specific DNS-over-HTTPS, direct-IP calls, hard-coded resolvers, IPv6 DNS and TCP DNS may bypass or are not supported in this preview.
- Same-domain ads, in-stream video ads, sponsored feed items, first-party promotions and ads integrated into content are not reliably blockable at DNS level.
- No HTTPS interception, certificate installation, stream modification or private API access.

## External media session bridge

- Requires explicit Android notification-listener opt-in.
- Uses `MediaSessionManager.getActiveSessions` and only actions exposed by each `PlaybackState`.
- Reads session metadata (title/artist) for display; does not read notification text or obtain raw audio bytes.
- The source app owns the stream, audio focus, background lifecycle, account entitlement and provider UI.
