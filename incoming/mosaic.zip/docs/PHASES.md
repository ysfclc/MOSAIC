# Phases and release gates

**Rule:** complete a phase, verify it, update this file and `PROJECT_STATE.md`, then begin the next. Do not label a feature complete until the required CI and device checks pass.

## Phase 1 — Native foundation and local playback

**Outcome:** native local audio indexing and one reliable background player.

Included: modular project, Compose design system, Home/Library/Player, read-only MediaStore index, Storage Access Framework open-file path, Media3 `MediaSessionService`, controller, queue and source adapter contracts.

Exit gate:
- [x] GitHub Actions debug build, unit tests and lint pass for the 0.2.0 baseline.
- [ ] App and permissions validated on Redmi Note 12 Pro 5G.
- [ ] Screen-off playback, notification, lock-screen, headset/Bluetooth, audio focus and noisy-route behavior verified.
- [ ] Local indexing does not copy, move or rename files; SAF playback works without broad library permission.

## Phase 2 — Durable library and source foundations

- Room schema and migrations for media identity, locations, collections, history and bookmarks.
- Incremental MediaStore sync and change observation; duplicate identity rules.
- Search/filter/sort and user collections.
- RSS podcast adapter and open internet-radio adapter.
- Permitted download queue, sleep timer, playback speed and queue persistence.
- Native video surface, orientation handling, picture-in-picture and accessible empty/error states.

Exit gate: library survives process death/reboot; RSS and open radio work; no duplicate binary copies; history and resume are correct.

## Phase 3 — System Media Shield and cross-app controls (ACTIVE PREVIEW)

- Device-wide DNS shield implemented as a consent-based Android `VpnService`.
- Route only the private DNS endpoint through the TUN interface; protect the upstream resolver socket from VPN recursion.
- Forward IPv4/UDP queries over authenticated DNS-over-TLS to AdGuard Public DNS.
- Display shield state, resolver identity, VPN consent and known limitations.
- Discover Android active media sessions after explicit notification-access opt-in; display metadata and supported play/pause/previous/next actions.
- Keep MOSAIC's native Media3 player independent and reliable in the background.
- Remove the Browser-first ad-filter implementation from navigation and product scope.

Initial implementation limits: IPv4 UDP DNS only; fragmented DNS requests, DNS-over-TCP, app-specific DoH and hard-coded resolvers may bypass the shield. The upstream DoT connection supports IPv4 and IPv6 addresses. DNS-level filtering cannot remove same-domain/in-stream/sponsored-feed ads. External media controls cannot override source-app background rules.

Exit gate:
- [ ] CI build, Kotlin tests, Python contract tests and lint pass.
- [ ] Shield establishes and tears down cleanly; resolver failure returns SERVFAIL and does not deadlock app traffic.
- [ ] Test normal DNS, blocked domain behavior, VPN replacement warning, Private DNS interaction and recovery after network changes.
- [ ] Verify that ordinary non-DNS traffic does not enter the TUN route.
- [ ] Test YouTube, Spotify, Facebook, Instagram and other apps on the target device; record exact observable results rather than assuming support.
- [ ] External session actions work only when the provider exposes them; no notification text or audio bytes are read.
- [ ] Screen-off MOSAIC-owned playback remains stable while Shield is active.

## Phase 4 — Official platform integrations

- Spotify official Android App Remote after user authorization, client configuration and terms review. Spotify retains streaming/audio/background ownership.
- YouTube official metadata/search and compliant visible playback only. Preserve ads/player UI; no hidden background player or audio extraction.
- Re-check current provider policies and SDK availability before each release.
- Surface per-account/per-item/per-session capabilities honestly.

Exit gate: provider tests and policy review pass; unsupported capabilities are shown as unavailable, never simulated.

## Phase 5 — Local media intelligence

- On-device transcription, timestamps, language detection and user-triggered translation.
- Chapters, summaries, highlights and citations to media timestamps.
- Semantic search and processing queue with cancellation, retry, provenance and deletion.

Exit gate: original media remains unchanged; processing is auditable and controllable.

## Phase 6 — Automation, backup and ecosystem

- User-defined import and processing rules.
- Exportable metadata/manifests and manual local/external backup with restore tests.
- Optional cross-device sync, Android Auto and casting only where they materially improve the product.

Exit gate: export/restore integrity is verified, sync is optional, and data remains portable.
