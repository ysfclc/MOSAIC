# Security and privacy baseline

- Local media is read through Android APIs. The library index is metadata; it is not a hidden media-copy operation.
- Broad audio permission is requested only when the user asks to scan the device. Open Document is the narrow single-file alternative.
- URI grants are persisted only for files the user explicitly selects and only with read permission.
- No TLS interception, user certificate installation, HTTPS payload inspection, audio capture, DRM circumvention, private provider API scraping or credential harvesting.
- The DNS shield is an explicit, user-consented Android `VpnService`. Its TUN route is limited to a private DNS endpoint; normal app traffic is not routed through MOSAIC.
- Supported DNS queries are forwarded to AdGuard Public DNS over TLS. The resolver can see queried hostnames and source network information as part of DNS service operation; the DNS payload is encrypted in transit. Do not describe this as local-only DNS processing.
- The VPN must call `VpnService.protect()` on its upstream socket to prevent DNS-over-TLS traffic from looping back through its own TUN route. On Android 14+, the VPN foreground service uses the `systemExempted` type for an active user-configured VPN and declares its matching permission.
- Android has one active VPN slot. Before enabling the Shield, explain that it can replace another VPN. Disable/revoke must close the tunnel and resolver socket.
- The first implementation handles IPv4 UDP DNS only. App-specific DoH, direct-IP requests, hard-coded DNS, IPv6 and TCP DNS may bypass or be unsupported. Failures must be visible and must not be logged with full DNS query payloads.
- Notification access is requested only when the user asks to enable external media controls. `NotificationListenerService` is used as the system gate for `MediaSessionManager`; notification title/body content is not read. Media metadata and transport actions are used only to render/control the exposed active session.
- External media sessions remain owned by their apps. MOSAIC does not copy or re-stream their protected audio bytes, and does not override their background-playback rules.
- No telemetry, analytics SDK, remote AI API, sign-in provider or app-owned advertising SDK is included in this preview.
- API tokens, cookies, user profiles, private files and credentials must never be committed in ZIP snapshots.
- ZIP import validates archive paths and file types and excludes Git history, signing materials, local config and secret-like content. Treat a ZIP uploaded to a public repository as public content.
