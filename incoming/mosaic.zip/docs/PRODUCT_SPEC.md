# Product specification — MOSAIC

## Product statement

MOSAIC is a native Android personal media environment: a reliable player for media the user owns or is permitted to play, a device-wide DNS shield for known third-party ad/tracker domains, and a unified remote-control surface for media sessions exposed by other Android apps.

## Primary job to be done

“When I listen to or watch media across my phone, I want playback and controls to behave consistently, background audio to work wherever the source permits it, and known ad/tracker network requests to be filtered across my apps without pretending every provider restriction can be bypassed.”

## User promise

- Local and permitted media plays through one MOSAIC-owned Media3 session and can continue in the background.
- The app inserts no advertisements.
- An optional user-approved DNS shield filters known third-party ad/tracker domains for apps that use Android's system DNS.
- MOSAIC can control external media only when the source exposes an Android media session or an authorized official remote API.
- MOSAIC does not intercept, record or re-stream protected audio/video from other applications.
- Original local files stay in their existing locations.

## Product areas

- Home: current playback, library state and quick access to Shield.
- Library: local items, collections and source metadata.
- Player: one MOSAIC-owned queue, timeline, transport, speed, timer and route controls.
- Shield: device DNS filtering status, explicit VPN enable/disable, media-session permission and external session transport controls.
- Source integrations: RSS, radio and official provider adapters when supported.
- Intelligence: optional local transcription, translation, summary and semantic search.
- Settings: privacy, permissions, source controls, backup and diagnostics.

## Release gates

A successful Gradle build is not device acceptance. The Shield is not accepted until DNS behavior, fallback behavior, app compatibility, VPN conflict handling, media-session visibility and screen-off playback have been tested on the target Redmi device.

## System-wide DNS shield

- The Shield uses Android `VpnService` with a narrowly routed local TUN interface. The only routed destination is MOSAIC's local DNS endpoint; normal app traffic does not traverse the tunnel.
- Supported IPv4/UDP DNS queries are forwarded to AdGuard Public DNS over authenticated DNS-over-TLS. AdGuard's public resolver applies its maintained ad/tracker/phishing filtering.
- The resolver receives the DNS hostnames requested by the device. MOSAIC does not install a user certificate, decrypt HTTPS, inspect media streams, modify app payloads or capture audio.
- The VPN is optional, foreground-visible and requires Android's explicit VPN consent. Android permits one active VPN at a time; the UI must disclose that enabling MOSAIC may replace another VPN.
- This preview handles IPv4 UDP DNS only. It does not yet cover IPv6 DNS, DNS-over-TCP, app-specific DoH, direct-IP requests or hard-coded third-party resolvers. Device testing must verify how Private DNS and OEM networking behave when the VPN is enabled.
- DNS filtering blocks domains, not individual ad objects. It cannot reliably remove same-domain ads, in-stream ads, sponsored feed posts, first-party promotions or content-integrated advertising. It must never be described as a universal ad remover.
- The resolver is a third-party service. The user should be told that domain lookups are transmitted to AdGuard over encrypted transport; no claim of a completely local DNS engine is permitted.

## Background playback and source ownership

- MOSAIC-owned local files, permitted RSS enclosures, open radio streams and authorized direct media use the shared Media3 `PlaybackService` and can continue in the background.
- External media sessions remain owned by the source app. MOSAIC may display metadata and issue only the transport actions reported by the session after explicit notification-access opt-in.
- Android notification access is used as the supported gate for `MediaSessionManager.getActiveSessions`. MOSAIC does not read notification text or extract audio bytes.
- A remote play command does not grant background rights. Source apps decide whether their playback continues when the UI is hidden or the screen is off.
- YouTube's official integration cannot be used to remove YouTube ads, extract its audio or convert its player to hidden/background audio. The installed YouTube app and the user's account entitlement govern playback.
- Spotify remains the audio owner. The current preview discovers its Android media session where exposed; a future official App Remote connector requires authorization and current terms review.
- Facebook, Instagram and other social apps may not expose video as a media session at all. MOSAIC cannot force their in-feed video to continue after they pause it.

## Source capability labels

- **MOSAIC PLAYER:** MOSAIC owns decoding and the Media3 session; background is supported only for permitted sources.
- **EXTERNAL SESSION:** the other app owns the stream; MOSAIC can display/control only exposed actions.
- **REFERENCE ONLY:** MOSAIC can retain/open a reference but cannot play or control the source.

## Explicit non-goals

- No TLS interception, certificate installation, private API scraping, DRM circumvention, subscription/paywall bypass or unauthorized stream extraction.
- No claim that DNS filtering removes every ad or that an external media controller overrides provider playback rules.
- No hidden audio capture, notification-content harvesting or automatic upload of media metadata.
