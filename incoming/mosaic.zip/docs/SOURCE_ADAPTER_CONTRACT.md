# Source adapter contract

## Purpose

Adapters isolate source-specific discovery, authentication, availability and resolution. The rest of MOSAIC consumes provider-neutral records and explicit capabilities.

## Required descriptor

- Stable source ID and display name.
- Whether the source requires network.
- Capabilities for browse, search, native playback, background playback, seek, speed control, offline copy, transcript and external controls.
- User-visible authentication requirement and connection state.

## Required operations

`browse(query)` returns `MediaItemRecord` values; `resolve(mediaId)` returns a `ResolvedMediaSource` or `null`. An adapter may add pagination, refresh, collection and authorization operations later, but must not mutate canonical library or player state directly.

## Capability rules

- Capability is evaluated per adapter and, where necessary, per item/session/account.
- `NATIVE_PLAYBACK` means MOSAIC is allowed and technically able to play the resolved item in its own player.
- `BACKGROUND_PLAYBACK` means that exact source/item can legally and technically continue through the MOSAIC service when the UI is backgrounded.
- `OFFLINE_COPY` means an offline copy is permitted and technically supported. It is not inferred merely because bytes are reachable.
- `EXTERNAL_CONTROLS` means the source exposes controllable actions, not that MOSAIC owns the stream.
- No capability is granted by guessing from a URL or by observing a notification alone.

## Current sources

- `LocalMediaSourceAdapter`: MediaStore-backed local items; MOSAIC owns playback and background lifecycle.
- RSS: future feed/episode metadata and enclosure URL adapter; direct playback only where permitted.
- Radio: future open-stream adapter with codec/ICY metadata and reconnect policy.
- YouTube: only official metadata and compliant visible playback; no ad removal, extraction or hidden background playback.
- Spotify: official remote-control interface only after user authorization and current terms review; no Spotify audio URI is exposed to MOSAIC.

## Cross-app bridge semantics

- Android external sessions are discovered only after explicit notification-access opt-in, through `MediaSessionManager.getActiveSessions`.
- The bridge reads the session's permitted metadata/actions; it does not read notification text or copy audio bytes.
- A remote action is forwarded to the app that owns the session. It does not change that app's background rules or account entitlement.
- The system DNS shield is not a media source adapter: it filters supported DNS host lookups via the Android VPN API and does not inspect app media payloads.
