# MOSAIC project state — session handoff

**Project:** MOSAIC / Personal Media OS  
**Repository:** `ysfclc/MOSAIC`  
**Branch base:** `main` at integrated source commit `931e92311d92dae576d7c6fed9df0a03dfc9299c`  
**Working source:** 0.3.0-system-shield-preview  
**Current delivery focus:** Phase 3 — System Media Shield and cross-app controls

## Product correction

The previous 0.2.0 preview added a small WebView filter and browser screen. That was the wrong slice for the primary product requirement. This source removes Browser from navigation and replaces it with a native Shield surface focused on device DNS filtering and external Android media-session controls.

## Current implementation in this source snapshot

- Home / Library / Player / Shield Compose navigation.
- Read-only MediaStore audio catalog and Storage Access Framework single-file playback.
- Media3 ExoPlayer in `MediaSessionService` for MOSAIC-owned background playback.
- `SystemAdBlockVpnService`: Android `VpnService`, explicit VPN consent, foreground notification and a DNS-only IPv4 TUN route.
- Local TUN DNS endpoint is inside `10.111.0.0/30`; only `10.111.0.2/32` is routed through the tunnel.
- DNS queries are sent over authenticated DNS-over-TLS to AdGuard Public DNS (`dns.adguard-dns.com`, bootstrap IPv4 `94.140.14.14` / `94.140.15.15`). The upstream socket is protected from VPN recursion.
- `DnsPacketCodec`: parser/response builder for IPv4 UDP DNS only; rejects fragmented IPv4 DNS requests and fragments oversized IPv4 UDP responses to the TUN MTU; no TCP DNS transport yet. The upstream DoT client can connect to AdGuard over IPv4 or IPv6.
- `ExternalMediaSessionBridge`: opt-in notification listener, active-session metadata and supported play/pause/previous/next commands. No notification text or external audio bytes are read.
- Browser screen, WebView ad policy and old browser tests were removed from this preview.

## Truthful capability limits

- DNS can block known third-party ad/tracker hostnames for apps using system DNS. It cannot reliably remove same-domain ads, in-stream video ads, sponsored feed posts, first-party promotions or content-integrated ads.
- Apps using app-specific DoH, hard-coded resolver endpoints, direct IP or unsupported DNS paths may bypass. Current packet handler supports IPv4 UDP only; IPv6 and TCP DNS coverage is not implemented.
- Enabling the Shield occupies Android's single VPN slot and may replace another VPN. The user explicitly approves this through `VpnService.prepare`.
- DNS queries reach AdGuard Public DNS over encrypted transport. This is not a fully local resolver.
- MOSAIC cannot force YouTube, Spotify, Facebook, Instagram or any other app to continue playback after the app pauses itself. External controls are available only when Android exposes a controllable session. YouTube's official policy does not permit ad removal or a hidden background player. Spotify remains the owner of its own stream and background lifecycle.

## Verification status

- Baseline 0.2.0 build: GitHub Actions run `41957296181` passed ZIP validation, source verifier, Python tests, Gradle tests, lint and debug APK assembly.
- 0.3.0 System Shield source: **not yet built by CI**. JVM codec tests and Python contract tests have been added/updated; local Python checks and structural checks must pass before handoff.
- `python3 tools/verify_source.py`: PASS (35 structural/source checks).
- `python3 -m unittest discover -s tools/tests -v`: PASS (12/12).
- AndroidManifest.xml XML parse: PASS.
- The DNS codec's six JVM test cases passed in a standalone Kotlin/JVM harness. A later repeated compiler invocation timed out; no Gradle test task was run.
- The local sandbox has no Android SDK and cannot download Gradle because internet/DNS is unavailable. Therefore no local Android app compilation or lint claim is made.
- No physical Redmi Note 12 Pro 5G test has been performed. VPN establishment, AdGuard reachability, DNS behavior, active media-session actions, battery behavior and screen-off playback remain acceptance gates.

## Next actions

1. Upload `MOSAIC-System-Media-Shield-Source.zip` to `incoming/mosaic.zip` and run the existing Build MOSAIC Android APK workflow.
2. Fix any CI compile/lint/test errors before installing the APK.
3. On the Redmi, test Shield enable/disable, DNS normal/block responses, VPN conflict and Private DNS behavior, and verify that normal app traffic is unaffected.
4. Test media-session discovery/actions for YouTube, Spotify, Facebook and Instagram individually. Record which expose sessions; do not infer support.
5. Add IPv6 and TCP DNS support, resolver configuration, rule diagnostics and block counters only after the first tunnel is validated.

## Handoff integrity

- This working tree was reconstructed from successful CI artifact `MOSAIC-Integrated-Repository` from run `41957296181`.
- The GitHub connector is read-only in this session; no branch, commit or remote file was changed by this work.
- The ZIP importer preserves `.github/workflows/build-apk.yml`; upload the complete source snapshot to `incoming/mosaic.zip` to use the existing pipeline.
