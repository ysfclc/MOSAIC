# MOSAIC System Media Shield preview — build handoff

**Date:** 2026-11-05  
**Source version:** `0.3.0-system-shield-preview`  
**Base:** integrated `main` source from successful CI run `41957296181`, commit `931e92311d92dae576d7c6fed9df0a03dfc9299c`.

## Product correction

Removed the previous WebView Browser destination and its in-app-only request filter. The primary cross-app surface is now a native Shield screen with a DNS-only Android VPN and an opt-in external media-session controller.

## Implemented in source

- Android `VpnService` with explicit `VpnService.prepare()` consent, a foreground notification, and a narrowly scoped TUN route for `10.111.0.2/32` inside `10.111.0.0/30`.
- IPv4/UDP DNS parser/response codec. The service forwards the DNS message through authenticated DNS-over-TLS to `dns.adguard-dns.com`; the upstream socket is protected from VPN recursion.
- Session controls use `MediaSessionManager` after the user enables notification access; only controls advertised by each session are offered. Notification contents and audio data are not captured.
- MOSAIC's own Media3 background player and the original local library remain intact.
- Browser, WebView ad-filter source and previous browser-only tests are removed from active app navigation.
- Updated architecture, product, security, provider capability, task and handoff documentation.

## Known limits — do not overstate

- The initial TUN packet handler supports IPv4 UDP DNS only. IPv6 DNS, DNS-over-TCP and fragmented DNS requests are not handled.
- DNS filtering only blocks resolver-listed third-party domains. It does not reliably remove same-domain ads, in-stream ads, sponsored feed content or first-party promotions. App-specific DoH, direct-IP and hard-coded resolver paths can bypass it.
- DNS lookups are sent to AdGuard Public DNS over encrypted TLS; AdGuard can see queried hostnames. This is not a local-only DNS engine.
- Android has one active VPN slot; VPN coexistence and Android Private DNS need physical-device testing.
- External media-session control cannot override another app's background policy. YouTube ads/background restrictions remain; Spotify owns its stream and lifecycle. Facebook/Instagram may not publish a controllable media session for all content.

## Verification performed in working sandbox

- `python3 tools/verify_source.py`: PASS (35 checks).
- `python3 -m unittest discover -s tools/tests -v`: PASS (12/12).
- Android manifest XML parsing: PASS.
- `DnsPacketCodecTest`: 6/6 passed in a standalone Kotlin/JVM harness. A later repeat compiler run timed out; the project Gradle test task was not run.
- No Android Gradle build or lint run: Android SDK is unavailable in this sandbox and Gradle distribution could not be downloaded because network/DNS access is unavailable.
- No physical-device test has been performed.

## Handoff

GitHub connector writes are unavailable in this session (branch/write API returned HTTP 403); no remote commit or new APK was created. Upload the complete `MOSAIC-System-Media-Shield-Source.zip` to `incoming/mosaic.zip`, then run the existing **Build MOSAIC Android APK** workflow. Fix any CI compile/lint/test failures before installing or testing the APK. Preserve this note with the imported source.
